package ru.syrzhn.simplefilemanager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

import ru.syrzhn.simplefilemanager.data.Prefs;
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity;
import ru.syrzhn.simplefilemanager.service.ScreenStartCypherForegroundService;

import static androidx.core.content.ContextCompat.startForegroundService;
import static ru.syrzhn.simplefilemanager.data.Constants.METHOD;
import static ru.syrzhn.simplefilemanager.data.Constants.SELECT_LIST;

public class BootStartCypherReciever extends BroadcastReceiver {

    final String LOG_TAG = "StartShutdown_LOG";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(LOG_TAG, "onReceive " + intent.getAction());

        Context c = context.getApplicationContext();

        if (Objects.equals(intent.getAction(), Intent.ACTION_BOOT_COMPLETED)) {
            Log.d(LOG_TAG, "onReceive ACTION_BOOT_COMPLETED");
            Toast.makeText(c, c.getResources().getString(R.string.on_complete_boot), Toast.LENGTH_LONG).show();

            SharedPreferences sharedPreferences = c.getSharedPreferences(Prefs.PREF_NAME, Context.MODE_PRIVATE);
            String s1 = sharedPreferences.getString(Prefs.SLECTED_PATHS, null);
            if (s1 == null || s1.isEmpty())
                return;
            String[] strPaths = s1.split(";");
            ArrayList<String> arrayList = new ArrayList<>(
                    Arrays.asList(strPaths)
                            .subList(0, strPaths.length)
            );
            Intent intentService = new Intent(c, ScreenStartCypherForegroundService.class);
            intentService.putExtra(METHOD, "decrypt");
            intentService.putStringArrayListExtra(SELECT_LIST, arrayList);
            startForegroundService(c, intentService);
        }
        else if (Objects.equals(intent.getAction(), Intent.ACTION_SHUTDOWN)) {
            Log.d(LOG_TAG, "onReceive ACTION_SHUTDOWN");
            Toast.makeText(c, c.getResources().getString(R.string.on_shutdown), Toast.LENGTH_LONG).show();

            ArrayList<String> arrayList = MainActivity.Companion.getSelectedFilesList().getUriArray();
            Intent intentService = new Intent(c, ScreenStartCypherForegroundService.class);
            intentService.putExtra(METHOD, "encrypt");
            intentService.putStringArrayListExtra(SELECT_LIST, arrayList);
            startForegroundService(c, intentService);
        }
    }
}
