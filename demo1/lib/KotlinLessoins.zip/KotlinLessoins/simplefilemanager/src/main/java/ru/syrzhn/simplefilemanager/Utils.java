package ru.syrzhn.simplefilemanager;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.util.Log;
import android.webkit.MimeTypeMap;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings({"ResultOfMethodCallIgnored"})
public class Utils {
     private static final String TAG = "Utils";

    public static String C_AUDIO = "a";
    public static String C_VIDEO = "v";
    public static String C_TEXT = "t";
    public static String C_ZIP = "z";
    public static String C_OFFICE = "o";
    public static String C_DROID = "d";
    public static String C_BOOK = "b";
    public static String C_IMAGE = "i";
    public static String C_MARKUP = "m";
    public static String C_APP = "x";
    public static String C_PDF = "p";
    public static String MIME_ALL = "*/*";

    private final static String[][] mimes = { // should be sorted!
            { ".3gpp", "audio/3gpp", C_AUDIO },
            { ".7z",   "application/x-7z-compressed", C_ZIP },
            { ".aif",  "audio/x-aiff", C_AUDIO },
            { ".apk",  "application/vnd.android.package-archive", C_DROID },
            { ".arj",  "application/x-arj", C_ZIP },
            { ".au",   "audio/basic", C_AUDIO },
            { ".avi",  "video/x-msvideo", C_VIDEO },
            { ".b1",   "application/x-b1", C_APP },
            { ".bmp",  "image/bmp", C_IMAGE },
            { ".bz",   "application/x-bzip2", C_ZIP },
            { ".bz2",  "application/x-bzip2", C_ZIP },
            { ".cab",  "application/x-compressed", C_ZIP },
            { ".cer",  "application/pkix-cert", C_APP },
            { ".chm",  "application/vnd.ms-htmlhelp", C_OFFICE },
            { ".conf", "application/x-conf", C_APP },
            { ".csv",  "text/csv", C_TEXT },
            { ".db",   "application/x-sqlite3", C_APP },
            { ".dex",  "application/octet-stream", C_DROID },
            { ".djvu", "image/vnd.djvu", C_IMAGE },
            { ".doc",  "application/msword", C_OFFICE },
            { ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", C_OFFICE },
            { ".epub", "application/epub+zip", C_BOOK },
            { ".fb2",  "application/fb2", C_BOOK },
            { ".flac", "audio/flac", C_AUDIO },
            { ".flv",  "video/x-flv", C_VIDEO },
            { ".gif",  "image/gif", C_IMAGE },
            { ".gpx",  "application/gpx+xml", C_MARKUP },
            { ".gtar", "application/x-gtar", C_ZIP },
            { ".gz",   "application/x-gzip", C_ZIP },
            { ".htm",  "text/html", C_MARKUP },
            { ".html", "text/html", C_MARKUP },
            { ".img",  "application/x-compressed", C_ZIP },
            { ".jar",  "application/java-archive", C_ZIP },
            { ".java", "text/java", C_TEXT },
            { ".jpeg", "image/jpeg", C_IMAGE },
            { ".jpg",  "image/jpeg", C_IMAGE },
            { ".js",   "text/javascript", C_TEXT },
            { ".kml",  "application/vnd.google-earth.kml+xml", C_MARKUP },
            { ".kmz",  "application/vnd.google-earth.kmz", C_MARKUP },
            { ".log",  "text/plain", C_TEXT },
            { ".lst",  "text/plain", C_TEXT },
            { ".lzh",  "application/x-lzh", C_ZIP },
            { ".m3u",  "application/x-mpegurl", C_AUDIO },
            { ".md5",  "application/x-md5", C_APP },
            { ".mid",  "audio/midi", C_AUDIO },
            { ".midi", "audio/midi", C_AUDIO },
            { ".mkv",  "video/x-matroska", C_VIDEO },
            { ".mobi", "application/x-mobipocket", C_BOOK },
            { ".mov",  "video/quicktime", C_VIDEO },
            { ".mp2",  "video/mpeg", C_VIDEO },
            { ".mp3",  "audio/mp3", C_AUDIO },
            { ".mp4",  "video/mp4", C_VIDEO },
            { ".mpeg", "video/mpeg", C_VIDEO },
            { ".mpg",  "video/mpeg", C_VIDEO },
            { ".odex", "application/octet-stream", C_DROID },
            { ".ods",  "application/vnd.oasis.opendocument.spreadsheet", C_OFFICE },
            { ".odt",  "application/vnd.oasis.opendocument.text", C_OFFICE },
            { ".oga",  "audio/ogg", C_AUDIO },
            { ".ogg",  "audio/ogg", C_AUDIO },    // RFC 5334
            { ".ogv",  "video/ogg", C_VIDEO },    // RFC 5334
            { ".opml", "text/xml", C_MARKUP },
            { ".pdf",  "application/pdf", C_PDF },
            { ".pfx",  "application/x-pkcs12", C_APP },
            { ".php",  "text/php", C_MARKUP },
            { ".pmd",  "application/x-pmd", C_OFFICE },   //      PlanMaker Spreadsheet
            { ".png",  "image/png", C_IMAGE },
            { ".ppt",  "application/vnd.ms-powerpoint", C_OFFICE },
            { ".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation", C_OFFICE },
            { ".prd",  "application/x-prd", C_OFFICE },   //      SoftMaker Presentations Document
            { ".ra",   "audio/x-pn-realaudio", C_AUDIO },
            { ".ram",  "audio/x-pn-realaudio", C_AUDIO },
            { ".rar",  "application/x-rar-compressed", C_ZIP },
            { ".rtf",  "application/rtf", C_OFFICE },
            { ".sh",   "application/x-sh", C_APP },
            { ".so",   "application/octet-stream", C_APP },
            { ".sqlite","application/x-sqlite3", C_APP },
            { ".svg",  "image/svg+xml", C_IMAGE },
            { ".swf",  "application/x-shockwave-flash", C_VIDEO },
            { ".sxw",  "application/vnd.sun.xml.writer", C_OFFICE },
            { ".tar",  "application/x-tar", C_ZIP },
            { ".tcl",  "application/x-tcl", C_APP },
            { ".tgz",  "application/x-gzip", C_ZIP },
            { ".tif",  "image/tiff", C_IMAGE },
            { ".tiff", "image/tiff", C_IMAGE },
            { ".tmd",  "application/x-tmd", C_OFFICE },   //      TextMaker Document
            { ".txt",  "text/plain", C_TEXT },
            { ".vcf",  "text/x-vcard", C_OFFICE },
            { ".wav",  "audio/wav", C_AUDIO },
            { ".wma",  "audio/x-ms-wma", C_AUDIO },
            { ".wmv",  "video/x-ms-wmv", C_VIDEO },
            { ".xls",  "application/vnd.ms-excel", C_OFFICE },
            { ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", C_OFFICE },
            { ".xml",  "text/xml", C_MARKUP },
            { ".xsl",  "text/xml", C_MARKUP },
            { ".zip",  "application/zip", C_ZIP }
    };

    public static String getMimeByExt( String ext ) {
        if( str( ext ) ) {
            String[] descr = getTypeDescrByExt( ext );
            if( descr != null ) return descr[1];
            // ask the system
            MimeTypeMap mime_map = MimeTypeMap.getSingleton();
            if( mime_map != null ) {
                String mime = mime_map.getMimeTypeFromExtension( ext.substring( 1 ) );
                if( str( mime ) ) return mime;
            }
        }
        return MIME_ALL;
    }

    public static boolean str( String s ) {
        return s != null && s.length() > 0;
    }

    public static String[] getTypeDescrByExt( String ext ) {
        ext = ext.toLowerCase();
        int from = 0, to = mimes.length;
        for( int l = 0; l < mimes.length; l++ ) {
            int idx = ( to - from ) / 2 + from;
            String tmp = mimes[idx][0];
            if( tmp.compareTo( ext ) == 0 )
                return mimes[idx];
            int cp;
            for( cp = 1;; cp++ ) {
                if( cp >= ext.length() ) {
                    to = idx;
                    break;
                }
                if( cp >= tmp.length() ) {
                    from = idx;
                    break;
                }
                char c0 = ext.charAt( cp );
                char ct = tmp.charAt( cp );
                if( c0 < ct ) {
                    to = idx;
                    break;
                }
                if( c0 > ct ) {
                    from = idx;
                    break;
                }
            }
        }
        return null;
    }

    public static String getFileExt( String file_name ) {
        if( file_name == null )
            return "";
        int dot = file_name.lastIndexOf( "." );
        return dot >= 0 ? file_name.substring( dot ) : "";
    }

    public static String joinEx(String[] a, String sep, int from) {
        if( a == null )
            return "";
        StringBuilder buf = new StringBuilder( 256 );
        boolean first = true;
        for( int i = from; i < a.length; i++ ) {
            if( first )
                first = false;
            else if( sep != null )
                buf.append( sep );
            buf.append( a[i] );
        }
        return buf.toString();
    }

    public static void deleteSubFolders(Context context, File folder) {
        if (!folder.isDirectory()) {
            if (SDCardOperations.Companion.pathOnSDCard(folder.getAbsolutePath())) {
                Uri uri = Utils.makeUri(context, folder.getAbsolutePath());
                try {
                    DocumentsContract.deleteDocument(context.getContentResolver(), uri);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
            else {
                folder.delete();
            }
            return;
        }
        File[] files = folder.listFiles();

        if (files == null) {
            return;
        }
        for (File file : files)  {
            if (file.isDirectory()) {
                deleteSubFolders(context, file);
            }
            else {
                if (SDCardOperations.Companion.pathOnSDCard(file.getAbsolutePath())) {
                    Uri uri = Utils.makeUri(context, file.getAbsolutePath());
                    try {
                        DocumentsContract.deleteDocument(context.getContentResolver(), uri);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                } else {
                    file.delete();
                }
            }
        }
        if (SDCardOperations.Companion.pathOnSDCard(folder.getAbsolutePath())) {
            Uri uri = Utils.makeUri(context, folder.getAbsolutePath());
            try {
                DocumentsContract.deleteDocument(context.getContentResolver(), uri);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        else {
            folder.delete();
        }
    }

    public static void copyDirectory(Context context, File source, File target, Boolean overwrite) throws IOException {
        if (!source.isDirectory()) {
            File newFile = target;
            if (newFile.exists() && !overwrite)
                return;
            InputStream in = new FileInputStream(source);
            OutputStream out;
            if (target.isDirectory()) {
                String path = target.getAbsolutePath();
                if (SDCardOperations.Companion.pathOnSDCard(path)) {
                    ContentResolver cr = context.getContentResolver();
                    String mime = Utils.getMimeByExt( Utils.getFileExt(source.getName()));
                    Uri detinationUri = Utils.makeUri(context, path);
                    Uri externalFile = DocumentsContract.createDocument(cr, detinationUri, mime, source.getName());
                    assert externalFile != null;
                    out = cr.openOutputStream(externalFile);
                }
                else {
                    boolean success = true;
                    if (!target.exists())
                        success = target.mkdirs();
                    if (!success)
                        throw new IOException("Cannot create dir " + target.getAbsolutePath());
                    newFile = new File(target.getAbsolutePath() + File.separator + source.getName());
                    out = new FileOutputStream(newFile);
                }
            }
            else {
                String path = target.getParent();
                assert path != null;
                if (SDCardOperations.Companion.pathOnSDCard(path)) {
                    ContentResolver cr = context.getContentResolver();
                    String mime = Utils.getMimeByExt( Utils.getFileExt(source.getName()));
                    Uri detinationUri = Utils.makeUri(context, path);
                    Uri externalFile = DocumentsContract.createDocument(cr, detinationUri, mime, source.getName());
                    assert externalFile != null;
                    out = cr.openOutputStream(externalFile);
                }
                else {
                    out = new FileOutputStream(newFile);
                }
            }
            // Copy the bits from instream to outstream
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                assert out != null;
                out.write(buf, 0, len);
            }
            in.close();
            assert out != null;
            out.close();
            return;
        }
        File newFolder = target;
        String path = target.getAbsolutePath();
        if (SDCardOperations.Companion.pathOnSDCard(path)) {
            if (!target.getName().equals(source.getName())) {
                Uri detinationUri = Utils.makeUri(context, path);
                createFolderOnExternalStorage(context, source.getName(), detinationUri);
            }
            else {
                path = target.getParent();
                Uri detinationUri = Utils.makeUri(context, path);
                createFolderOnExternalStorage(context, source.getName(), detinationUri);
            }
            newFolder = new File(path + File.separator + source.getName());
        }
        else {
            boolean success = true;
            if (!target.getName().equals(source.getName())) {
                if (!target.exists())
                    success = target.mkdirs();
                if (!success)
                    throw new IOException("Cannot create dir " + target.getAbsolutePath());
                newFolder = new File(path + File.separator + source.getName());
            }
            if (!newFolder.exists())
                success = newFolder.mkdirs();
            if (!success)
                throw new IOException("Cannot create dir " + target.getAbsolutePath());
        }
        File[] files = source.listFiles();
        if (files == null) return;
        for (File f : files) {
            copyDirectory(context, f, newFolder, overwrite);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static Uri makeUri(Context ctx, String path ) {
        if( path == null )  return null;
        String[]  ps = path.split( "/" );
        if(ps.length < 3 || !"storage".equals(ps[1]))
            return null;
        String vol_doc_id, doc_id;
        if( "emulated".equals( ps[2] ) ) {
            vol_doc_id = "primary:";
            doc_id = vol_doc_id + Utils.joinEx( ps, "/", 4 );
        } else {
            vol_doc_id = ps[2] + ":";
            doc_id = vol_doc_id + Utils.joinEx( ps, "/", 3 );
        }
        Uri tree_uri = DocumentsContract.buildTreeDocumentUri( "com.android.externalstorage.documents", vol_doc_id );
        if( tree_uri == null || !isPermitted( ctx, tree_uri ) )
            return null;
        return DocumentsContract.buildDocumentUriUsingTree( tree_uri, doc_id );
    }

    public static boolean isPermitted( Context ctx, Uri uri_ ) {
        try {
            if( DocumentsContract.isDocumentUri( ctx, uri_ ) ) {
                List<String> segms = uri_.getPathSegments();
                uri_ = uri_.buildUpon().path( null ).appendPath( segms.get(0) ).appendPath( segms.get(1) ).build();
            }
            ctx.getContentResolver().takePersistableUriPermission( uri_,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION |
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION );
            return true;
        } catch( Exception e ) {
            Log.e( TAG, uri_.toString() );
        }
        return false;
    }

    public static void createFolderOnExternalStorage(Context context, String folder, Uri parentFolderUri) {
        ContentResolver cr = context.getContentResolver();
        File folderFile = new File(SDCardOperations.Companion.getSDCardPath().getAbsolutePath() + folder);
        Uri folderUri = makeUri(context, folderFile.getAbsolutePath());
        try {
            if (folderFile.exists()) {
                DocumentsContract.deleteDocument(cr, folderUri);
            }
            DocumentsContract.createDocument(cr, parentFolderUri, DocumentsContract.Document.MIME_TYPE_DIR, folder);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    public static boolean requestPermission(Activity act, String[] perms, int rpc) {
        ArrayList<String> al = new ArrayList<>(perms.length);
        for (String perm : perms) {
            int cp = act.checkPermission(perm, android.os.Process.myPid(), android.os.Process.myUid());
            if (cp != PackageManager.PERMISSION_GRANTED)
                al.add(perm);
        }
        if( al.size() > 0 ) {
            act.requestPermissions( al.toArray(perms), rpc );
            return false;
        }
        return true;
    }
}
