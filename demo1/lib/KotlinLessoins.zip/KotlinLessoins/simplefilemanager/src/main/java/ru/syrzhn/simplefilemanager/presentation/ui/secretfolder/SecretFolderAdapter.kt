@file:Suppress("DEPRECATION")

package ru.syrzhn.simplefilemanager.presentation.ui.secretfolder

import android.content.Intent
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import kotlinx.android.synthetic.main.item_file.view.*
import ru.syrzhn.simplefilemanager.R
import ru.syrzhn.simplefilemanager.data.AboutFile
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_FOLDER
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_UNKNOWN
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_UPDIR
import ru.syrzhn.simplefilemanager.presentation.ui.AFilesListFrag

class SecretFolderAdapter : RecyclerView.Adapter<SecretFolderAdapter.SecretFolderViewHolder>() {

    private val fileList = mutableListOf<AboutFile>()

    var itemClickListener: AFilesListFrag? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SecretFolderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false)
        return SecretFolderViewHolder(view)
    }

    override fun getItemCount(): Int {
        return fileList.size
    }

    override fun onBindViewHolder(holder: SecretFolderViewHolder, position: Int) {
        holder.bind(fileList[position])
    }

    fun setFiles(files: List<AboutFile>) {
        fileList.clear()
        fileList.addAll(files)
        notifyDataSetChanged()
    }

    inner class SecretFolderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val fileIcon: ImageView = itemView.file_icon
        private val fileName: TextView = itemView.file_name
        private val fileInfo: TextView = itemView.file_info

        private lateinit var currentFile: AboutFile

        fun bind(file: AboutFile) {
            currentFile = file
            fileName.text = currentFile.name
            fileInfo.text = currentFile.info
            setDrawableOnLoad(position)
        }

        init {
            itemView.setOnClickListener {
                itemClickListener?.onItemClick(currentFile)
            }

            itemView.setOnLongClickListener { view ->
                itemClickListener?.onItemLongClick(adapterPosition, view)
                true
            }
        }

        private fun setDrawableOnLoad(position: Int) {
            val file = fileList[position]
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(file.uri)
            intent.type = file.mimeType
            val matches = fileIcon.context.packageManager.queryIntentActivities(intent, 0)

            if (file.mimeType == TYPE_FOLDER)
                Glide.with(itemView).load(R.drawable.folder).override(100, 100)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .listener(object : RequestListener<Drawable> {
                        override fun onResourceReady(
                            resource: Drawable?,
                            model: Any?,
                            target: Target<Drawable>?,
                            dataSource: DataSource?,
                            isFirstResource: Boolean
                        ): Boolean {
                            if (file.selected) {
                                val layerDrawable = tickOverlay(resource)
                                fileIcon.setImageDrawable(layerDrawable)
                                return true
                            }
                            return false
                        }

                        override fun onLoadFailed(
                            e: GlideException?,
                            model: Any?,
                            target: Target<Drawable>?,
                            isFirstResource: Boolean
                        ): Boolean {
                            return false
                        }
                    }).into(fileIcon)
            else if (file.mimeType == TYPE_UPDIR)
                Glide.with(itemView).load(R.drawable.updir21).override(100, 100)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .listener(object : RequestListener<Drawable> {
                        override fun onResourceReady(
                            resource: Drawable?,
                            model: Any?,
                            target: Target<Drawable>?,
                            dataSource: DataSource?,
                            isFirstResource: Boolean
                        ): Boolean {
                            return false
                        }

                        override fun onLoadFailed(
                            e: GlideException?,
                            model: Any?,
                            target: Target<Drawable>?,
                            isFirstResource: Boolean
                        ): Boolean {
                            return false
                        }
                    }).into(fileIcon)
            else if (file.mimeType == TYPE_UNKNOWN || matches.isNullOrEmpty())
                Glide.with(itemView).load(R.drawable.file_icon_default).override(100, 100)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .listener(object : RequestListener<Drawable> {
                        override fun onResourceReady(
                            resource: Drawable?,
                            model: Any?,
                            target: Target<Drawable>?,
                            dataSource: DataSource?,
                            isFirstResource: Boolean
                        ): Boolean {
                            if (file.selected) {
                                val layerDrawable = tickOverlay(resource)
                                fileIcon.setImageDrawable(layerDrawable)
                                return true
                            }
                            return false
                        }

                        override fun onLoadFailed(
                            e: GlideException?,
                            model: Any?,
                            target: Target<Drawable>?,
                            isFirstResource: Boolean
                        ): Boolean {
                            return false
                        }
                    }).into(fileIcon)
            else if (file.mimeType.startsWith("image") || file.mimeType.startsWith("video")) {
                val cropOptions = RequestOptions().centerCrop()
                Glide.with(itemView).load(file.uri).apply(cropOptions).override(100, 100)
                    .diskCacheStrategy(DiskCacheStrategy.ALL).placeholder(R.drawable.file_icon_default)
                    .listener(object : RequestListener<Drawable> {
                        override fun onResourceReady(
                            resource: Drawable?,
                            model: Any?,
                            target: Target<Drawable>?,
                            dataSource: DataSource?,
                            isFirstResource: Boolean
                        ): Boolean {
                            if (file.selected) {
                                val layerDrawable = tickOverlay(resource)
                                fileIcon.setImageDrawable(layerDrawable)
                                return true
                            }
                            return false
                        }

                        override fun onLoadFailed(
                            e: GlideException?,
                            model: Any?,
                            target: Target<Drawable>?,
                            isFirstResource: Boolean
                        ): Boolean {
                            if (file.selected) {
                                val r = fileIcon.resources
                                val layerDrawable =
                                    tickOverlay(ResourcesCompat.getDrawable(r, R.drawable.file_icon_default, r.newTheme()))
                                fileIcon.setImageDrawable(layerDrawable)
                                return true
                            }
                            return false
                        }
                    }).into(fileIcon)

            }
            else
                Glide.with(itemView)
                    .load(matches[0].loadIcon(fileIcon.context.packageManager))
                    .override(100, 100).diskCacheStrategy(DiskCacheStrategy.ALL)
                    .listener(object : RequestListener<Drawable> {
                        override fun onResourceReady(
                            resource: Drawable?,
                            model: Any?,
                            target: Target<Drawable>?,
                            dataSource: DataSource?,
                            isFirstResource: Boolean
                        ): Boolean {
                            if (file.selected) {
                                val layerDrawable = tickOverlay(resource)
                                fileIcon.setImageDrawable(layerDrawable)
                                return true
                            }
                            return false
                        }

                        override fun onLoadFailed(
                            e: GlideException?,
                            model: Any?,
                            target: Target<Drawable>?,
                            isFirstResource: Boolean
                        ): Boolean {
                            return false
                        }
                    }).into(fileIcon)
        }

        private fun tickOverlay(drawable: Drawable?): LayerDrawable {
            val r = fileIcon.resources
            val layers = arrayOfNulls<Drawable>(2)
            layers[0] = drawable
            layers[0]?.alpha = 50
            layers[1] = ResourcesCompat.getDrawable(r, R.drawable.checkmark, r.newTheme())

            return LayerDrawable(layers)
        }
    }
}