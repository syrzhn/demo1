package ru.syrzhn.simplefilemanager.domain;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AES128_2 {
    public static AES128_2 getInstance() {
        AES128_2 localInstance = instance;
        if (localInstance == null) {
            synchronized (AES128_2.class) {
                localInstance = instance;
                if (localInstance == null) {
                    instance = localInstance = new AES128_2();
                }
            }
        } return localInstance;
    }
    private static volatile AES128_2 instance;

    private static final int READ_WRITE_BLOCK_BUFFER = 1024;
    private static final String ALGO_FILE_ENCRYPTOR = "AES/CBC/PKCS5Padding";
    private static final String ALGO_SECRET_KEY = "AES";
    private static final String KEY_STR = "PwwRzW2Y0lrRddH7";
    private static final String SPEC_STR = "IZMfBAQMOpacEyZZ";


    public static void encryptFile(File fileIn, File fileOut) {
        InputStream in = null; OutputStream out = null;
        try {
            in = new FileInputStream(fileIn); out = new FileOutputStream(fileOut);

            IvParameterSpec ivParameterSpec = new IvParameterSpec(SPEC_STR.getBytes("UTF-8"));
            SecretKeySpec keySpec = new SecretKeySpec(KEY_STR.getBytes("UTF-8"), ALGO_SECRET_KEY);

            Cipher c = Cipher.getInstance(ALGO_FILE_ENCRYPTOR);
            c.init(Cipher.ENCRYPT_MODE, keySpec, ivParameterSpec);

            out = new CipherOutputStream(out, c);

            int count = 0;

            byte[] buffer = new byte[READ_WRITE_BLOCK_BUFFER];

            while ((count = in.read(buffer)) != -1) {
                out.write(buffer, 0, count);
            }
        } catch (IOException | NoSuchAlgorithmException | InvalidKeyException | InvalidAlgorithmParameterException | NoSuchPaddingException e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null)
                    in.close();
                if (out != null)
                    out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void decryptFile(File fileIn, File fileOut) {
        InputStream in = null; OutputStream out = null;
        try {
            in = new FileInputStream(fileIn); out = new FileOutputStream(fileOut);

            IvParameterSpec ivParameterSpec = new IvParameterSpec(SPEC_STR.getBytes("UTF-8"));
            SecretKeySpec keySpec = new SecretKeySpec(KEY_STR.getBytes("UTF-8"), ALGO_SECRET_KEY);

            Cipher c = Cipher.getInstance(ALGO_FILE_ENCRYPTOR);
            c.init(Cipher.DECRYPT_MODE, keySpec, ivParameterSpec);

            out = new CipherOutputStream(out, c);

            int count = 0;

            byte[] buffer = new byte[READ_WRITE_BLOCK_BUFFER];

            while ((count = in.read(buffer)) > 0) {
                out.write(buffer, 0, count);
            }

        } catch (IOException | NoSuchAlgorithmException | InvalidKeyException | InvalidAlgorithmParameterException | NoSuchPaddingException e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null)
                    in.close();
                if (out != null)
                    out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
