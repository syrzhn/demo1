package ru.syrzhn.simplefilemanager.presentation.ui

interface IOnBackPressed {
    fun onBackPressed(): Boolean
}