package ru.syrzhn.simplefilemanager.data

class Constants {
    companion object {
        const val TYPE_FOLDER = "folder"
        const val TYPE_UPDIR = "updir"
        const val TYPE_UNKNOWN = "unknown"

        const val CONTROLLED_APP_NAME = "TotalCommander"
        const val CYPHERED_FILE_NAME = "cyphered.zip"
        const val METHOD = "METOD"
        const val DELAY = "DELAY"
        const val ENCRYPT_DELAY = 5000
        const val DECRYPT_DELAY = 5000
        const val SELECT_LIST = "selectedFilesList"
        const val FILES_ENCRYPTED_RESULT = "filesEncrypted"
    }
}