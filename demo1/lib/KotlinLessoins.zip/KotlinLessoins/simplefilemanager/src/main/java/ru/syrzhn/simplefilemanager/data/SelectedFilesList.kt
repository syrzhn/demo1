package ru.syrzhn.simplefilemanager.data

class SelectedFilesList {
    private val items = mutableListOf<AboutFile>()

    val size
        get() = items.size

    fun getItemsCount(): Int {
        return items.size
    }

    fun getItem(position: Int): AboutFile {
        return items[position]
    }

    fun getItemByName(name: String): AboutFile? {
        for (position in items.indices) {
            if (items[position].name == name) {
                return items[position]
            }
        }; return null
    }

    fun findInItems(file: AboutFile): Int {
        for (position in items.indices) {
            if (items[position].uri == file.uri) {
                return position
            }
        }; return -1
    }

    fun removeItem(file: AboutFile): Boolean {
        val position = findInItems(file)
        if (position > -1) {
            items.removeAt(position)
            return true
        }
        else {
            return false
        }
    }

    fun addItem(file: AboutFile) {
        if (!removeItem(file)) {
            items.add(file)
        }
    }

    fun clear() {
        items.clear()
    }

    fun getItemsList(): List<AboutFile> {
        return items
    }

    fun getUriArray(): ArrayList<String> {
        val uris = ArrayList<String>()
        for (file in items) {
            uris.add(file.uri)
        }
        return uris
    }

    fun addAll(files: List<AboutFile>) {
        items.addAll(files)
    }
}