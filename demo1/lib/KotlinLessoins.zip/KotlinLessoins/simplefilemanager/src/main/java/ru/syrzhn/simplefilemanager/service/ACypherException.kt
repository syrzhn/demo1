package ru.syrzhn.simplefilemanager.service

class ACypherException(override val message: String) : InterruptedException(message)