package ru.syrzhn.simplefilemanager.data

import android.webkit.MimeTypeMap
import ru.syrzhn.simplefilemanager.domain.Domain
import java.io.File
import java.util.*

class AboutFile (
    var name: String,
    var info: String,
    var uri: String,
    var mimeType: String,
    var selected: Boolean
)
{
    constructor(file: File) : this(file.name,"", file.path,"", false) {
        val name = file.name
        val uri = file.path
        val extension = uri.substring(uri.lastIndexOf(".") + 1).toLowerCase(Locale.ROOT)
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
        val selected = false//(activity as MainActivity).findFilesInSelected(file)

        when {
            file.isDirectory -> {
                this.name = name
                this.info = ""
                this.uri = uri
                this.mimeType = Constants.TYPE_FOLDER
                this.selected = selected
            }
            mimeType.isNullOrEmpty() -> {
                this.name = name
                this.info = Domain.getSize(file)
                this.uri = uri
                this.mimeType = Constants.TYPE_UNKNOWN
                this.selected = selected
            }
            else -> {
                this.name = name
                this.info = Domain.getSize(file)
                this.uri = uri
                this.mimeType = mimeType.toString()
                this.selected = selected
            }
        }
    }

    constructor(file: File, selected: Boolean) : this(file.name,"", file.path,"", selected) {
        val name = file.name
        val uri = file.path
        val extension = uri.substring(uri.lastIndexOf(".") + 1).toLowerCase(Locale.ROOT)
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)

        when {
            file.isDirectory -> {
                this.name = name
                this.info = ""
                this.uri = uri
                this.mimeType = Constants.TYPE_FOLDER
                this.selected = selected
            }
            mimeType.isNullOrEmpty() -> {
                this.name = name
                this.info = Domain.getSize(file)
                this.uri = uri
                this.mimeType = Constants.TYPE_UNKNOWN
                this.selected = selected
            }
            else -> {
                this.name = name
                this.info = Domain.getSize(file)
                this.uri = uri
                this.mimeType = mimeType.toString()
                this.selected = selected
            }
        }
    }
}