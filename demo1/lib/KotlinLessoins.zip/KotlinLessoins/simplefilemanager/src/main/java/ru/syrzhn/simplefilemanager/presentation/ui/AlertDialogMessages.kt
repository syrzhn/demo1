package ru.syrzhn.simplefilemanager.presentation.ui

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import ru.syrzhn.simplefilemanager.R

@SuppressLint("InflateParams")
class AlertDialogMessages {
    companion object {
        fun noItemsSelected(context: Context) {
            val customTitle = LayoutInflater.from(context).inflate(R.layout.custom_title, null)
            customTitle.findViewById<TextView>(R.id.title_text).text = context.getString(R.string.no_items_selected)
            val customText = LayoutInflater.from(context).inflate(R.layout.custom_text_alertdialog, null)
            customText.findViewById<TextView>(R.id.custom_text).text = context.getString(R.string.to_select_items)

            val builder = AlertDialog.Builder(context)
                .setCustomTitle(customTitle)
                .setView(customText)
                .setCancelable(false)
                .setPositiveButton(context.getString(R.string.ok), null)
            builder.show()
        }

        fun alreadyExists(name: String, context: Context) {
            val customTitle = LayoutInflater.from(context).inflate(R.layout.custom_title, null)
            customTitle.findViewById<TextView>(R.id.title_text).text = name
            val customText = LayoutInflater.from(context).inflate(R.layout.custom_text_alertdialog, null)
            customText.findViewById<TextView>(R.id.custom_text).text = context.getString(R.string.already_exist)

            val builder = AlertDialog.Builder(context)
                .setCustomTitle(customTitle)
                .setView(customText)
                .setCancelable(false)
                .setPositiveButton(context.getString(R.string.ok), null)
            builder.show()
        }

        fun nameIsNull(context: Context) {
            val customTitle = LayoutInflater.from(context).inflate(R.layout.custom_title, null)
            customTitle.findViewById<TextView>(R.id.title_text).text = context.getString(R.string.empty_name)
            val customText = LayoutInflater.from(context).inflate(R.layout.custom_text_alertdialog, null)
            customText.findViewById<TextView>(R.id.custom_text).text = context.getString(R.string.enter_name)

            val builder = AlertDialog.Builder(context)
                .setCustomTitle(customTitle)
                .setView(customText)
                .setCancelable(false)
                .setPositiveButton(context.getString(R.string.ok), null)
            builder.show()
        }

        fun copyOrMoveIntoItself(copyOrMove: String, context: Context) {
            val customTitle = LayoutInflater.from(context).inflate(R.layout.custom_title, null)
            customTitle.findViewById<TextView>(R.id.title_text).text = context.getString(R.string.attention)
            val customText = LayoutInflater.from(context).inflate(R.layout.custom_text_alertdialog, null)

            if (copyOrMove == "copy")
                customText.findViewById<TextView>(R.id.custom_text).text = context.getString(R.string.cannot_copy_into_itself)
            else if (copyOrMove == "move")
                customText.findViewById<TextView>(R.id.custom_text).text = context.getString(R.string.cannot_move_into_itself)

            val builder = AlertDialog.Builder(context)
                .setCustomTitle(customTitle)
                .setView(customText)
                .setCancelable(false)
                .setPositiveButton(context.getString(R.string.ok), null)
            builder.show()
        }

        fun noResults(context: Context) {
            val customTitle = LayoutInflater.from(context).inflate(R.layout.custom_title, null)
            customTitle.findViewById<TextView>(R.id.title_text).text = context.getString(R.string.info)
            val customText = LayoutInflater.from(context).inflate(R.layout.custom_text_alertdialog, null)
            customText.findViewById<TextView>(R.id.custom_text).text = context.getString(R.string.no_results)

            val builder = AlertDialog.Builder(context)
                .setCustomTitle(customTitle)
                .setView(customText)
                .setCancelable(false)
                .setPositiveButton(context.getString(R.string.ok), null)
            builder.show()
        }

        fun showOnFirstStart(context: Context) {
            val customTitle = LayoutInflater.from(context.applicationContext).inflate(R.layout.custom_title, null)
            customTitle.findViewById<TextView>(R.id.title_text).text = context.getString(R.string.welcome)
            val customText = LayoutInflater.from(context).inflate(R.layout.custom_text_alertdialog, null)
            customText.findViewById<TextView>(R.id.custom_text).text = context.getString(R.string.welcome_message)

            AlertDialog.Builder(context)
                .setView(customText)
                .setCustomTitle(customTitle)
                .setCancelable(false)
                .setPositiveButton(context.getString(R.string.ok), null)
                .show()

            val prefs = context.getSharedPreferences("prefs", AppCompatActivity.MODE_PRIVATE)
            val editor = prefs.edit()
            editor.putBoolean("firstStart", false)
            editor.apply()
        }
    }
}