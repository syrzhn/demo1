@file:Suppress("DEPRECATION", "unused")

package ru.syrzhn.simplefilemanager.service

import android.app.*
import android.content.*
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.os.IBinder
import android.widget.Toast
import androidx.core.app.NotificationCompat
import ru.syrzhn.simplefilemanager.R
import ru.syrzhn.simplefilemanager.Utils
import ru.syrzhn.simplefilemanager.data.Constants.Companion.CONTROLLED_APP_NAME
import ru.syrzhn.simplefilemanager.data.Constants.Companion.CYPHERED_FILE_NAME
import ru.syrzhn.simplefilemanager.data.Constants.Companion.DELAY
import ru.syrzhn.simplefilemanager.data.Constants.Companion.FILES_ENCRYPTED_RESULT
import ru.syrzhn.simplefilemanager.data.Constants.Companion.METHOD
import ru.syrzhn.simplefilemanager.data.Constants.Companion.SELECT_LIST
import ru.syrzhn.simplefilemanager.data.Processes.findBackgrounProcess
import ru.syrzhn.simplefilemanager.domain.Domain.Companion.getFileSize
import ru.syrzhn.simplefilemanager.domain.ZipManager
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors


class ScreenStartCypherForegroundService : IntentService {
    private val TYPE_ENCRYPTION = "copy"
//    private val TYPE_ENCRYPTION = "zip"

    private var receiver: BroadcastReceiver? = null
    private val executorService: ExecutorService = Executors.newFixedThreadPool(1)

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Foreground Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            // Configure the notification channel.
            serviceChannel.description = "Channel description"
            serviceChannel.enableLights(true)
            serviceChannel.lightColor = Color.RED
            serviceChannel.vibrationPattern = longArrayOf(0, 1000, 500, 1000)
            serviceChannel.enableVibration(true)
            val notificationManager = getSystemService(NotificationManager::class.java)!!
            notificationManager.createNotificationChannel(serviceChannel)
        }
    }

    private fun createNotification(txt: String?): Notification {
        val notificationIntent = Intent(
            this@ScreenStartCypherForegroundService,
            MainActivity::class.java
        )
        notificationIntent.putExtra(FILES_ENCRYPTED_RESULT, filesEncrypted)
        notificationIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(
            this@ScreenStartCypherForegroundService,
            0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Screen foreground Service")
            .setContentText(txt)
            .setSmallIcon(R.drawable.ic_stat_name)
            .setLargeIcon(
                BitmapFactory.decodeResource(
                    resources,
                    R.drawable.ic_launcher_foreground
                )
            )
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    constructor(name: String?) : super(name)
    constructor() : super(CHANNEL_ID)

    override fun onCreate() {
        super.onCreate()
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val action = intent.action!!
                val cypher: ACypher = Cypher(10000, 500)
                val uncypher: ACypher = Uncypher(1000, 500)
                when (action) {
                    Intent.ACTION_SCREEN_ON -> {
                        Toast.makeText(context, "ACTION_SCREEN_ON", Toast.LENGTH_SHORT).show()
                        inDarkness = false
                    }
                    Intent.ACTION_USER_PRESENT -> {
                        Toast.makeText(context, "ACTION_USER_PRESENT", Toast.LENGTH_SHORT).show()
                        executorService.execute(uncypher)
                    }
                    Intent.ACTION_SCREEN_OFF -> {
                        inDarkness = true
                        executorService.execute(cypher)
                    }
                }
            }
        }
        val filter = IntentFilter(Intent.ACTION_SCREEN_ON)
        filter.addAction(Intent.ACTION_SCREEN_OFF)
        filter.addAction(Intent.ACTION_USER_PRESENT)
        registerReceiver(receiver, filter)
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        val input = intent.getStringExtra(METHOD)
        val delay = intent.getIntExtra(DELAY, 0)
        val arr = intent.getStringArrayListExtra(SELECT_LIST) as ArrayList<out String>?
        arr?.let {
            listToSave.clear()
            listToSave.addAll(arr)
        }
        createNotificationChannel()
        startForeground(1, createNotification(input))
        val fileZip = File(applicationContext.filesDir.absolutePath + File.separator + CYPHERED_FILE_NAME)
        if (fileZip.exists()) {
            val sizeZipFile = getFileSize(fileZip)
            val preferences = getSharedPreferences(packageName, MODE_PRIVATE)
            val size = preferences.getLong(STORED_ZIP_FILE_SIZE, 0)
            if (sizeZipFile != size) {
                startForeground(1, createNotification("Incorrect stored file!"))
                return Service.START_NOT_STICKY
            }
        }
        when (input) {
            "encrypt" -> {
                inDarkness = true
                val cypher: ACypher = Cypher(delay.toLong(), (delay / 5).toLong())
                executorService.execute(cypher)
            }
            "decrypt" -> {
                inDarkness = false
                val uncypher: ACypher = Uncypher(delay.toLong(), (delay / 5).toLong())
                executorService.execute(uncypher)
            }
            "light" -> inDarkness = false
            "dark" -> inDarkness = true
        }
        return Service.START_NOT_STICKY
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE) {
            inDarkness = false
        }
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onHandleIntent(intent: Intent?) {}

    @Throws(ACypherException::class)
    private fun encryptFiles(context: Context) {
        if (TYPE_ENCRYPTION.equals("copy")) {
            for (aFile in listToSave) {
                val file = File(aFile)
                Utils.copyDirectory(context, file, context.filesDir, true)
            }
        }
        else {
            val listFiles = mutableListOf<File>()
            for (aFile in listToSave) {
                val file = File(aFile)
                if (file.exists()) {
                    listFiles.add(file)
                }
            }
            val zipFilePath = context.filesDir.absolutePath + File.separator + CYPHERED_FILE_NAME
            ZipManager.packAndEncrypt(listFiles, zipFilePath)
            val zipFile = File(zipFilePath)
            val preferences = getSharedPreferences(packageName, MODE_PRIVATE)
            val ed: SharedPreferences.Editor = preferences.edit()
            ed.putLong(STORED_ZIP_FILE_SIZE, zipFile.length())
            ed.apply()
        }
        for (uri in listToSave) {
            val file = File(uri)
            Utils.deleteSubFolders(context, file)
        }
        filesEncrypted = true
        startForeground(1, createNotification("encrypted"))
    }

    @Throws(ACypherException::class)
    private fun decryptFiles(context: Context) {
        if (TYPE_ENCRYPTION.equals("zip")) {
            val zipFilePath = context.filesDir.absolutePath + File.separator + CYPHERED_FILE_NAME
            val zipFile = File(zipFilePath)
            if (!zipFile.exists())
                return
            ZipManager.unpackAndDecrypt(zipFilePath, context.filesDir.absolutePath)
        }
        val secretFileList = context.filesDir.listFiles()
        if (secretFileList == null || secretFileList.isEmpty())
            return
        for (file in secretFileList) {
            var selectedFile: File? = null
            val name = file.name
            for (uri in listToSave) {
                val aFile = File(uri)
                val aName = aFile.name
                if (aName == name) {
                    selectedFile = aFile
                    break
                }
            }
            selectedFile?.let {
                Utils.copyDirectory(context, file, selectedFile, true)
            }
        }
        for (file in secretFileList) {
            Utils.deleteSubFolders(context, file)
        }
        filesEncrypted = false
        // Send message
        startForeground(1, createNotification("decrypted"))
    }

    internal inner class Cypher(delay: Long, tickTime: Long) : ACypher(delay, tickTime) {
        override fun finish() {
            if (findBackgrounProcess(applicationContext, CONTROLLED_APP_NAME)) {
                startForeground(1, createNotification("Source folder is busy"))
                return
            }
            try {
                encryptFiles(applicationContext)
            } catch (e: ACypherException) {
                e.printStackTrace()
                startForeground(1, createNotification(e.message))
            }
        }

        override fun tickTimer() {
            if (!inDarkness) {
                startForeground(1, createNotification("cypher canceled"))
                cancel()
            }
        }
    }

    internal inner class Uncypher(delay: Long, tickTime: Long) : ACypher(delay, tickTime) {
        override fun finish() {
            try {
                decryptFiles(applicationContext)
            } catch (e: ACypherException) {
                e.printStackTrace()
                startForeground(1, createNotification(e.message))
            }
        }

        override fun tickTimer() {
            if (inDarkness) {
                startForeground(1, createNotification("uncypher canceled"))
                cancel()
            }
        }
    }

    companion object {
        val listToSave = ArrayList<String>()
        private const val CHANNEL_ID = "syrzhn_channel_id_01"

        @Volatile
        private var isActivityStarted = false
        private var inDarkness = false
        private var mSizeBefore: Long = 0
        private var mSizePacked: Long = 0
        private var mSizeAfter: Long = 0
        private var filesEncrypted: Boolean = false
        private const val STORED_ZIP_FILE_SIZE = "STORED_ZIP_FILE_SIZE"
    }
}