@file:Suppress("DEPRECATION", "UNUSED_ANONYMOUS_PARAMETER",
    "NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS",
    "RECEIVER_NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS"
)

package ru.syrzhn.simplefilemanager

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.DialogInterface
import android.os.AsyncTask
import android.view.LayoutInflater
import android.widget.TextView
import androidx.documentfile.provider.DocumentFile
import ru.syrzhn.simplefilemanager.SDCardOperations.Companion.copyToSDCard
import ru.syrzhn.simplefilemanager.SDCardOperations.Companion.createFolderOnSDCard
import ru.syrzhn.simplefilemanager.SDCardOperations.Companion.deleteOnSDCard
import ru.syrzhn.simplefilemanager.SDCardOperations.Companion.getChildrenOnSDCard
import ru.syrzhn.simplefilemanager.data.AboutFile
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_FOLDER
import ru.syrzhn.simplefilemanager.presentation.ui.AFilesListFrag
import ru.syrzhn.simplefilemanager.presentation.ui.AlertDialogMessages.Companion.alreadyExists
import ru.syrzhn.simplefilemanager.presentation.ui.AlertDialogMessages.Companion.copyOrMoveIntoItself
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.currentPath
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.rootPath
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.sdCardPath
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.selectedFilesList
import ru.syrzhn.simplefilemanager.presentation.ui.filemanager.FilesListFrag
import java.io.File
import java.util.*

class AsyncGetAllFiles : AsyncTask<AFilesListFrag, Void, List<AboutFile>>() {
    override fun doInBackground(vararg params: AFilesListFrag): List<AboutFile>? {
        val fileList = currentPath.listFiles()?.asList()

        return fileList?.let { params[0].fillList(it) }
    }
}

class AsyncCopySelected(private val frag: AFilesListFrag) :
    AsyncTask<FilesListFrag, Int, FilesListFrag>() {

    private val progressDialog = ProgressDialog(frag.context)
    private var copyState = 0.0
    private var selectedListSize = 0.0

    @SuppressLint("InflateParams")
    override fun onPreExecute() {
        val customTitle = LayoutInflater.from(frag.context).inflate(R.layout.custom_title, null)
        customTitle.findViewById<TextView>(R.id.title_text).text = frag.getString(
            R.string.copying
        )

        progressDialog.setCustomTitle(customTitle)
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
        progressDialog.max = 100
        progressDialog.progress = 0
        progressDialog.setCancelable(false)
        progressDialog.setButton(DialogInterface.BUTTON_NEGATIVE, frag.getString(R.string.cancel)) {
                dialog, which -> this.cancel(true)
        }
        progressDialog.show()
    }

    override fun doInBackground(vararg params: FilesListFrag): FilesListFrag? {
        val selectedList = params[0].listAdapter.getSelectedList()
        selectedList.forEach {
            if (it.mimeType == TYPE_FOLDER)
                selectedListSize += getFolderSize(File(it.uri))
            else
                selectedListSize += File(it.uri).length()
        }

        for (element in selectedList) {
            val file = File(currentPath.toString() + "/" + element.name)
            progressDialog.setProgressNumberFormat(((selectedList.indexOf(element) + 1).toString() + "/" + selectedList.size))

            if (element.mimeType == TYPE_FOLDER && !currentPath.toString()
                    .contains(element.uri) && !file.exists()
            ) {
                if (currentPath.toString().contains(sdCardPath.toString()))
                    copyFolderToSDCard(File(element.uri), params[0])
                else
                    copyFolder(File(element.uri))
            } else if (!file.exists() && !currentPath.toString().contains(element.uri)) {
                copyState += File(element.uri).length()
                publishProgress((copyState * 100 / selectedListSize).toInt())

                if (currentPath.toString().contains(sdCardPath.toString()))
                    copyToSDCard(
                        currentPath,
                        File(element.uri),
                        params[0]
                    )
                else
                    File(element.uri).copyTo(file)
            } else if (file.exists()) {
                params[0].activity!!.runOnUiThread {
                    alreadyExists(element.name, params[0].context!!)
                }
            } else {
                params[0].activity!!.runOnUiThread {
                    copyOrMoveIntoItself("copy", params[0].context!!)
                }
            }

            if (this.isCancelled)
                break
        }
        return params[0]
    }

    override fun onProgressUpdate(vararg values: Int?) {
        progressDialog.progress = values[0]!!
    }

    override fun onPostExecute(result: FilesListFrag) {
        progressDialog.hide()
        result.loadFiles()
    }

    override fun onCancelled(result: FilesListFrag) {
        progressDialog.dismiss()
        result.loadFiles()
    }

    private fun copyFolder(folder: File) {
        for (src in folder.walkTopDown()) {
            val relPath = src.toRelativeString(folder.parentFile)
            val dstFile = File(currentPath, relPath)

            copyState += src.length()
            publishProgress((copyState * 100 / selectedListSize).toInt())

            if (src.isDirectory)
                dstFile.mkdirs()
            else
                src.copyTo(dstFile)

            if (this.isCancelled)
                break
        }
    }

    private fun copyFolderToSDCard(folder: File, frag: FilesListFrag) {
        for (src in folder.walkTopDown()) {
            val relPath = src.toRelativeString(folder.parentFile)
            val dstFile = File(currentPath, relPath)

            copyState += src.length()
            publishProgress((copyState * 100 / selectedListSize).toInt())

            if (src.isDirectory)
                createFolderOnSDCard(dstFile.parentFile, src.name, frag)
            else
                copyToSDCard(dstFile.parentFile, src, frag)

            if (this.isCancelled)
                break
        }
    }
}

@Suppress("DEPRECATION")
class AsyncDeleteSelected(private val frag: FilesListFrag) :
    AsyncTask<FilesListFrag, Int, FilesListFrag>() {

    private val progressDialog = ProgressDialog(frag.context)
    private var deleteState = 0.0
    private var selectedListSize = 0.0

    @SuppressLint("InflateParams")
    override fun onPreExecute() {
        val customTitle = LayoutInflater.from(frag.context).inflate(R.layout.custom_title, null)
        customTitle.findViewById<TextView>(R.id.title_text).text = frag.getString(
            R.string.deleting
        )

        progressDialog.setCustomTitle(customTitle)
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
        progressDialog.max = 100
        progressDialog.progress = 0
        progressDialog.setCancelable(false)
        progressDialog.setButton(DialogInterface.BUTTON_NEGATIVE, frag.getString(R.string.cancel)) {
                dialog, which -> this.cancel(true)
        }
        progressDialog.show()
    }

    override fun doInBackground(vararg params: FilesListFrag): FilesListFrag {
        val selectedList = params[0].listAdapter.getSelectedList().toMutableList()
        selectedList.forEach {
            if (it.mimeType == TYPE_FOLDER)
                selectedListSize += getFolderSize(File(it.uri))
            else
                selectedListSize += File(it.uri).length()
        }

        for (position in selectedList.indices) {
            val fileUri = selectedList[position].uri
            val file = File(fileUri)
            progressDialog.setProgressNumberFormat(((position + 1).toString() + "/" + selectedList.size))

            if (selectedList[position].mimeType == TYPE_FOLDER) {
                if (currentPath.toString().contains(sdCardPath.toString())) {
                    val sdCardFolder =
                        getChildrenOnSDCard(currentPath, params[0])
                            ?.findFile(file.name)
                    if (sdCardFolder != null) {
                        deleteFolderOnSDCard(sdCardFolder, params[0])
                    }
                }
                else {
                    deleteFolder(file)
                }
            }
            else {
                deleteState += File(selectedList[position].uri).length()
                publishProgress((deleteState * 100 / selectedListSize).toInt())

                if (currentPath.toString().contains(sdCardPath.toString()))
                    deleteOnSDCard(currentPath, file, params[0])
                else
                    file.delete()
            }
            if (this.isCancelled)
                break
            selectedFilesList.removeItem(selectedList[position])
        }
        return params[0]
    }

    override fun onProgressUpdate(vararg values: Int?) {
        progressDialog.progress = values[0]!!
    }

    override fun onPostExecute(result: FilesListFrag) {
        progressDialog.hide()
        result.loadFiles()
        result.mainActivity.updateSelectedList()
    }

    override fun onCancelled(result: FilesListFrag?) {
        progressDialog.dismiss()
        result?.loadFiles()
    }

    fun deleteFolder(folderOrFile: File) {
        if (folderOrFile.isDirectory) {
            for (element in folderOrFile.listFiles()) {
                deleteState += element.length()
                publishProgress((deleteState * 100 / selectedListSize).toInt())
                deleteFolder(element)

                if (this.isCancelled)
                    return
            }
        }
        if (this.isCancelled)
            return

        folderOrFile.delete()
    }

    fun deleteFolderOnSDCard(folderOrFile: DocumentFile, activity: FilesListFrag) {
        if (folderOrFile.isDirectory) {
            for (element in folderOrFile.listFiles()) {
                deleteState += element.length()
                publishProgress((deleteState * 100 / selectedListSize).toInt())
                deleteFolderOnSDCard(element, activity)

                if (this.isCancelled)
                    return
            }
        }
        if (this.isCancelled)
            return

        folderOrFile.delete()
    }
}

@Suppress("DEPRECATION")
class AsyncMoveSelected(private val frag: FilesListFrag) :
    AsyncTask<FilesListFrag, Int, FilesListFrag>() {

    private val progressDialog = ProgressDialog(frag.context)
    private val asyncDeleteSelected = AsyncDeleteSelected(frag)
    private var moveState = 0.0
    private var selectedListSize = 0.0

    @SuppressLint("InflateParams")
    override fun onPreExecute() {
        val customTitle =
            LayoutInflater.from(frag.context).inflate(R.layout.custom_title, null)
        customTitle.findViewById<TextView>(R.id.title_text).text = frag.getString(
            R.string.moving
        )

        progressDialog.setCustomTitle(customTitle)
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
        progressDialog.max = 100
        progressDialog.progress = 0
        progressDialog.setCancelable(false)
        progressDialog.setButton(
            DialogInterface.BUTTON_NEGATIVE,
            frag.getString(R.string.cancel)
        ) { dialog, which ->
            this.cancel(true)
        }
        progressDialog.show()
    }

    override fun doInBackground(vararg params: FilesListFrag): FilesListFrag {
        val selectedList = params[0].listAdapter.getSelectedList()
        selectedList.forEach {
            if (it.mimeType == TYPE_FOLDER)
                selectedListSize += getFolderSize(File(it.uri))
            else
                selectedListSize += File(it.uri).length()
        }

        for (element in selectedList) {
            val file = File(currentPath.toString() + "/" + element.name)
            progressDialog.setProgressNumberFormat(((selectedList.indexOf(element) + 1).toString() + "/" + selectedList.size))

            if (currentPath.toString() != element.uri && !file.exists()) {
                if (currentPath.toString().contains(sdCardPath.toString())) {
                    if (element.mimeType == TYPE_FOLDER) {
                        moveFolderToSDCard(File(element.uri), params[0])

                        if (element.uri.contains(rootPath.toString()))
                            asyncDeleteSelected.deleteFolder(File(element.uri))
                        else {
                            val sdCardFolder =
                                getChildrenOnSDCard(File(element.uri), params[0])
                            if (sdCardFolder != null) {
                                asyncDeleteSelected.deleteFolderOnSDCard(sdCardFolder, params[0])
                            }
                        }
                    } else {
                        moveState += File(element.uri).length()
                        publishProgress((moveState * 100 / selectedListSize).toInt())

                        copyToSDCard(
                            currentPath,
                            File(element.uri),
                            params[0]
                        )
                        if (element.uri.contains(rootPath.toString()))
                            File(element.uri).delete()
                        else
                            deleteOnSDCard(
                                File(
                                    element.uri.substring(
                                        0,
                                        element.uri.lastIndexOf("/")
                                    )
                                ), File(element.uri), params[0]
                            )
                    }
                } else if (currentPath.toString()
                        .contains(rootPath.toString())
                ) {
                    if (element.mimeType == TYPE_FOLDER) {
                        if (element.uri.contains(rootPath.toString()))
                            File(element.uri).renameTo(file)
                        else {
                            moveFolder(File(element.uri))
                            val sdCardFolder =
                                getChildrenOnSDCard(File(element.uri), params[0])
                            if (sdCardFolder != null) {
                                asyncDeleteSelected.deleteFolderOnSDCard(sdCardFolder, params[0])
                            }
                        }
                    } else {
                        moveState += File(element.uri).length()
                        publishProgress((moveState * 100 / selectedListSize).toInt())

                        if (element.uri.contains(rootPath.toString()))
                            File(element.uri).renameTo(file)
                        else {
                            File(element.uri).copyTo(file)
                            deleteOnSDCard(
                                File(
                                    element.uri.substring(
                                        0,
                                        element.uri.lastIndexOf("/")
                                    )
                                ), File(element.uri), params[0]
                            )
                        }
                    }
                }
            } else if (file.exists()) {
                params[0].activity!!.runOnUiThread {
                    alreadyExists(file.name, params[0].context!!)
                }
            } else {
                params[0].activity!!.runOnUiThread {
                    copyOrMoveIntoItself("move", params[0].context!!)
                }
            }

            if (this.isCancelled)
                break
        }
        return params[0]
    }

    override fun onProgressUpdate(vararg values: Int?) {
        progressDialog.progress = values[0]!!
    }

    override fun onPostExecute(result: FilesListFrag) {
        progressDialog.hide()
        result.loadFiles()
    }

    override fun onCancelled(result: FilesListFrag) {
        progressDialog.dismiss()
        result.loadFiles()
    }

    private fun moveFolder(folder: File) {
        for (src in folder.walkTopDown()) {
            val relPath = src.toRelativeString(folder.parentFile)
            val dstFile = File(currentPath, relPath)

            moveState += src.length()
            publishProgress((moveState * 100 / selectedListSize).toInt())

            if (src.isDirectory)
                dstFile.mkdirs()
            else
                src.copyTo(dstFile)

            if (this.isCancelled) {
                asyncDeleteSelected.cancel(true)
                break
            }
        }
    }

    private fun moveFolderToSDCard(folder: File, listFrag: FilesListFrag) {
        for (src in folder.walkTopDown()) {
            val relPath = src.toRelativeString(folder.parentFile)
            val dstFile = File(currentPath, relPath)

            moveState += src.length()
            publishProgress((moveState * 100 / selectedListSize).toInt())

            if (src.isDirectory)
                createFolderOnSDCard(dstFile.parentFile, src.name, listFrag)
            else
                copyToSDCard(dstFile.parentFile, src, listFrag)

            if (this.isCancelled) {
                asyncDeleteSelected.cancel(true)
                break
            }
        }
    }
}

class AsyncSearch(private val input: String) :
    AsyncTask<FilesListFrag, Void, MutableList<File>>() {

    override fun doInBackground(vararg params: FilesListFrag): MutableList<File> {
        val result = mutableListOf<File>()

        currentPath.walk().forEach {
            if (it.name.toLowerCase(Locale.ROOT)
                    .contains(input.toLowerCase(Locale.ROOT)) && it.path != currentPath.toString()
            )
                result += it
        }
        return result
    }
}

private fun getFolderSize(folder: File): Double {
    var length = 0.0
    for (element in folder.listFiles()) {
        if (element.isFile)
            length += element.length()
        else
            length += getFolderSize(element)
    }
    return length
}