package ru.syrzhn.simplefilemanager

import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import ru.syrzhn.simplefilemanager.data.AboutFile
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.sdCardPath
import ru.syrzhn.simplefilemanager.presentation.ui.AFilesListFrag
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.currentPath
import ru.syrzhn.simplefilemanager.presentation.ui.filemanager.FilesListFrag
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.util.regex.Pattern

class SDCardOperations {

    companion object {

        fun copyToSDCard(dstPath: File, file: File, frag: FilesListFrag) {
            val sdCardFile = getChildrenOnSDCard(dstPath, frag)?.createFile("", file.name)
            val bufferSize = 8 * 1024
            val bufferedInput = BufferedInputStream(FileInputStream(file))
            val bufferedOutput =
                sdCardFile?.uri?.let {
                    BufferedOutputStream(
                        frag.activity!!.contentResolver.openOutputStream(
                            it
                        )
                    )
                }

            bufferedInput.use { input ->
                bufferedOutput.use { output ->
                    if (output != null) {
                        input.copyTo(output, bufferSize)
                    }
                }
            }
            bufferedInput.close()
            bufferedOutput?.flush()
            bufferedOutput?.close()
        }

        fun createFolderOnSDCard(dstPath: File, name: String, frag: AFilesListFrag) {
            getChildrenOnSDCard(dstPath, frag)?.createDirectory(name)
        }

        fun renameOnSDCard(input: AboutFile, newName: String, frag: AFilesListFrag) {
            getChildrenOnSDCard(currentPath, frag)?.findFile(input.name)?.renameTo(newName)
        }

        fun deleteOnSDCard(path: File, file: File, frag: AFilesListFrag) {
            getChildrenOnSDCard(path, frag)?.findFile(file.name)?.delete()
        }

        fun getChildrenOnSDCard(dstPath: File, frag: AFilesListFrag): DocumentFile? {
            try {
                var id = DocumentsContract.getTreeDocumentId(frag.getUri(frag.context!!))
                id += dstPath.toString().removePrefix(sdCardPath.toString())
                val childrenUri = DocumentsContract.buildDocumentUriUsingTree(frag.getUri(frag.context!!), id)
                return DocumentFile.fromTreeUri(frag.context!!, childrenUri)
            } catch (e: Exception) {
            }
            return null
        }

        fun pathOnSDCard(path: String): Boolean {
            if (sdCardPath == null)
                return false
            return path.contains(sdCardPath.absolutePath)
        }

        fun getSDCardPath(): File? {
            val storage: Array<File>? = File("/storage").listFiles()
            var sdCardPath: File? = null
            val pattern = Pattern.compile("([A-Z]|[0-9]){4}-([A-Z]|[0-9]){4}")

            if (storage != null) {
                for (element in storage) {
                    if (pattern.matcher(element.name).matches())
                        sdCardPath = element
                }
            }
            return sdCardPath
        }
    }
}