@file:Suppress("unused")

package ru.syrzhn.simplefilemanager.domain

import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.exception.ZipException
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionLevel
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ZipManager {

    companion object {
        private const val BUFFER = 2048
        private const val PASSWORD = "qwerty"

        /*
         * Zips a file at a location and places the resulting zip file at the toLocation
         * Example: zipFileAtPath("downloads/myfolder", "downloads/myFolder.zip");
         */
        @Suppress("RECEIVER_NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
        fun zipFileAtPath(sourcePath: String, toLocation: String) {
            val sourceFile = File(sourcePath)
            try {
                val origin: BufferedInputStream
                val dest = FileOutputStream(toLocation)
                val out =
                    ZipOutputStream(BufferedOutputStream(dest))
                if (sourceFile.isDirectory) {
                    zipSubFolder(out, sourceFile, sourceFile.parent.length)
                } else {
                    val data = ByteArray(BUFFER)
                    val fi = FileInputStream(sourcePath)
                    origin = BufferedInputStream(fi, BUFFER)
                    val entry =
                        ZipEntry(getLastPathComponent(sourcePath))
                    entry.time = sourceFile.lastModified() // to keep modification time after unzipping
                    out.putNextEntry(entry)
                    var count: Int
                    while (origin.read(data, 0, BUFFER).also { count = it } != -1) {
                        out.write(data, 0, count)
                    }
                }
                out.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        @Throws(IOException::class)
        private fun zipSubFolder(
            out: ZipOutputStream,
            folder: File,
            basePathLength: Int
        ) {
            val fileList = folder.listFiles()
            var origin: BufferedInputStream
            for (file in fileList!!) {
                if (file.isDirectory) {
                    zipSubFolder(out, file, basePathLength)
                } else {
                    val data = ByteArray(BUFFER)
                    val unmodifiedFilePath = file.path
                    val relativePath = unmodifiedFilePath
                        .substring(basePathLength)
                    val fi = FileInputStream(unmodifiedFilePath)
                    origin = BufferedInputStream(fi, BUFFER)
                    val entry = ZipEntry(relativePath)
                    entry.time = file.lastModified() // to keep modification time after unzipping
                    out.putNextEntry(entry)
                    var count: Int
                    while (origin.read(data, 0, BUFFER).also { count = it } != -1) {
                        out.write(data, 0, count)
                    }
                    origin.close()
                }
            }
        }

        /*
         * gets the last path component
         *
         * Example: getLastPathComponent("downloads/example/fileToZip");
         * Result: "fileToZip"
         */
        private fun getLastPathComponent(filePath: String): String {
            val segments = filePath.split("/".toRegex()).toTypedArray()
            return if (segments.isEmpty()) "" else segments[segments.size - 1]
        }

        fun unzip(zipFile: File?, targetDirectory: File?) {
            var zis: ZipInputStream? = null
            try {
                zis = ZipInputStream(
                    BufferedInputStream(
                        FileInputStream(zipFile)
                    )
                )
                var ze: ZipEntry
                var count: Int
                val buffer = ByteArray(8192)
                while (zis.nextEntry.also { ze = it } != null) {
                    val file = File(targetDirectory, ze.name)
                    val dir = if (ze.isDirectory) file else file.parentFile
                    if (!dir.isDirectory && !dir.mkdirs()) throw FileNotFoundException(
                        "Failed to ensure directory: " +
                                dir.absolutePath
                    )
                    if (ze.isDirectory) continue
                    FileOutputStream(file).use { fout ->
                        while (zis.read(buffer).also { count = it } != -1) fout.write(
                            buffer,
                            0,
                            count
                        )
                    }
                    // if time should be restored as well
                    val time = ze.time
                    if (time > 0) file.setLastModified(time)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            } finally {
                try {
                    zis!!.close()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }

        fun packAndEncrypt(sourceFolderPath: String, zipFilePath: String) {
            val sampleSourceFolderFile = File(sourceFolderPath)
            val parameters = ZipParameters()
            parameters.compressionMethod = CompressionMethod.STORE
            parameters.compressionLevel = CompressionLevel.FASTEST
            parameters.setEncryptFiles(true)
            parameters.setEncryptionMethod(EncryptionMethod.AES)
            parameters.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_128)
            try {
                val zipFile = ZipFile(zipFilePath, PASSWORD.toCharArray())
                if (sampleSourceFolderFile.isDirectory)
                    zipFile.addFolder(sampleSourceFolderFile, parameters)
                else
                    zipFile.addFile(sampleSourceFolderFile, parameters)
            } catch (e: ZipException) {
                e.printStackTrace()
            }
        }

        fun packAndEncrypt(listFiles: List<File>, zipFilePath: String) {
            val parameters = ZipParameters()
            parameters.compressionMethod = CompressionMethod.DEFLATE
            parameters.compressionLevel = CompressionLevel.FASTEST
            parameters.setEncryptFiles(true)
            parameters.setEncryptionMethod(EncryptionMethod.AES)
            parameters.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_128)
            try {
                val zipFile = ZipFile(zipFilePath, PASSWORD.toCharArray())
                for (file in listFiles) {
                    if (file.isDirectory)
                        zipFile.addFolder(file, parameters)
                    else
                        zipFile.addFile(file, parameters)
                }
            } catch (e: ZipException) {
                e.printStackTrace()
            }
        }

        fun unpackAndDecrypt(zipFilePath: String, destinationFolderPath: String) {
            val sampleZipFile = File(zipFilePath)
            if (!sampleZipFile.exists()) {
                return
            }
            try {
                val zipFile = ZipFile(zipFilePath)
                zipFile.setPassword(PASSWORD.toCharArray())
                zipFile.extractAll(destinationFolderPath)
            } catch (e: ZipException) {
                e.printStackTrace()
            }
        }
    }
}