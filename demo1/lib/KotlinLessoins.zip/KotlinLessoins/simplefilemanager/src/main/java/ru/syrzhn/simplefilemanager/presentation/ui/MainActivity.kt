package ru.syrzhn.simplefilemanager.presentation.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import ru.syrzhn.simplefilemanager.R
import ru.syrzhn.simplefilemanager.SDCardOperations.Companion.getSDCardPath
import ru.syrzhn.simplefilemanager.data.AboutFile
import ru.syrzhn.simplefilemanager.data.Constants.Companion.DECRYPT_DELAY
import ru.syrzhn.simplefilemanager.data.Constants.Companion.DELAY
import ru.syrzhn.simplefilemanager.data.Constants.Companion.ENCRYPT_DELAY
import ru.syrzhn.simplefilemanager.data.Constants.Companion.FILES_ENCRYPTED_RESULT
import ru.syrzhn.simplefilemanager.data.Constants.Companion.METHOD
import ru.syrzhn.simplefilemanager.data.Constants.Companion.SELECT_LIST
import ru.syrzhn.simplefilemanager.data.Prefs
import ru.syrzhn.simplefilemanager.data.SelectedFilesList
import ru.syrzhn.simplefilemanager.service.ScreenStartCypherForegroundService
import java.io.File

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    companion object {
        val sdCardPath: File? = getSDCardPath()
        val rootPath = File(Environment.getExternalStorageDirectory().absolutePath)
        var upPath: File = rootPath
        var currentPath: File = rootPath
            set(value) {
                upPath = if (sdCardPath != null && value == sdCardPath) {
                    value
                }
                else if (value == rootPath) {
                    value
                }
                else {
                    val location =
                        value.toString().substring(0, value.toString().lastIndexOf("/") + 1)
                    File(location)
                }
                field = value
            }
        var serviceStarted: Boolean = false
        var filesEncrypted: Boolean = false
        var backPressed: IOnBackPressed? = null

        val selectedFilesList = SelectedFilesList()

        var isFABOpen = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
//        val intent = getIntent()
        intent.let { filesEncrypted = intent.getBooleanExtra(FILES_ENCRYPTED_RESULT, false)}

        viewPager.adapter = SectionsPagerAdapter(this, supportFragmentManager)

        tabs.setupWithViewPager(viewPager)

        fab.setOnClickListener {
            if (!isFABOpen){
                isFABOpen = true
                fabStart.visibility = View.VISIBLE
                fabStop.visibility = View.VISIBLE
                fabStart.animate().translationY(-getResources().getDimension(R.dimen.standard_55))
                fabStop.animate().translationY(-getResources().getDimension(R.dimen.standard_105))
            }
            else {
                fabStart.animate().translationY(0F)
                fabStop.animate().translationY(0F)
                fabStart.visibility = View.INVISIBLE
                fabStop.visibility = View.INVISIBLE
                isFABOpen = false
            }
        }

        fabStart.setOnClickListener {
            if (selectedFilesList.size == 0)
                return@setOnClickListener
            if (filesEncrypted) {
                val serviceIntent = Intent(this, ScreenStartCypherForegroundService::class.java)
                serviceIntent.putExtra(METHOD, "decrypt")
                serviceIntent.putExtra(DELAY, DECRYPT_DELAY)
                ContextCompat.startForegroundService(this, serviceIntent)
            }
            else {
                val arrayList = selectedFilesList.getUriArray()
                val serviceIntent = Intent(this, ScreenStartCypherForegroundService::class.java)
                serviceIntent.putExtra(METHOD, "encrypt")
                serviceIntent.putExtra(DELAY, ENCRYPT_DELAY)
                serviceIntent.putStringArrayListExtra(SELECT_LIST, arrayList)
                ContextCompat.startForegroundService(this, serviceIntent)
            }
            serviceStarted = true
            finish()
        }

        fabStop.setOnClickListener {
            val serviceIntent = Intent(this, ScreenStartCypherForegroundService::class.java)
            stopService(serviceIntent)
            serviceStarted = false
        }
    }

    override fun onStart() {
        super.onStart()
        val sharedPreferences = getSharedPreferences(Prefs.PREF_NAME, Context.MODE_PRIVATE)
        val s = sharedPreferences.getString(Prefs.CURRENT_PATH, currentPath.absolutePath)
        s?.let { currentPath = File(s) }

        val s1 = sharedPreferences?.getString(Prefs.SLECTED_PATHS, null)
        s1?.let {
            selectedFilesList.clear()
            val strPaths = s1.split(";")
            for (i in 0 until strPaths.size - 1) {
                val str = strPaths[i]
                val file = File(str)
                selectedFilesList.addItem(AboutFile(file, true))
            }
        }
    }

    override fun onStop() {
        val sharedPreferences = getSharedPreferences(Prefs.PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString(Prefs.CURRENT_PATH, currentPath.absolutePath)

        val sb = StringBuilder()
        for (i in 0 until selectedFilesList.getItemsCount()) {
            sb.append(selectedFilesList.getItem(i).uri).append(";")
        }
        editor.putString(Prefs.SLECTED_PATHS, sb.toString())
        editor.apply()
        super.onStop()
    }

    override fun onBackPressed() {
        if (isFABOpen) {
            fabStart.animate().translationY(0F)
            fabStop.animate().translationY(0F)
            fabStart.visibility = View.INVISIBLE
            fabStop.visibility = View.INVISIBLE
            isFABOpen = false
            return@onBackPressed
        }
        when (viewPager.currentItem) {
            0 -> {
                if (backPressed == null) {
                    super.onBackPressed()
                    return
                } else if (backPressed!!.onBackPressed()) {
                    super.onBackPressed()
                }
            }
            1 -> viewPager.currentItem = 0
            2 -> viewPager.currentItem = 1
            else -> viewPager.currentItem = 0
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_options, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.delete -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    fun addFileToSelected(file: AboutFile) {
        selectedFilesList.addItem(file)
    }

    fun updateFilesLis() {
        (viewPager.adapter as SectionsPagerAdapter).filesListFrag.loadFiles()
    }

    fun updateSelectedList() {
        (viewPager.adapter as SectionsPagerAdapter).selectedListFrag.loadFiles()
    }

    fun findFilesInSelected(file: File): Boolean {
        val aboutFile = AboutFile(file)
        val position = selectedFilesList.findInItems(aboutFile)
        return position > -1
    }
}