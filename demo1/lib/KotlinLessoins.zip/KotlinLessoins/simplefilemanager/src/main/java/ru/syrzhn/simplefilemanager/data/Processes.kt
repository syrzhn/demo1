package ru.syrzhn.simplefilemanager.data

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
//import android.view.accessibility.AccessibilityEvent

object Processes {
    private const val MAX_RECENT_TASKS = 100

    @SuppressLint("NewApi")
    fun foundAnyEvents(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
            return true
        }
        val mUsageStatsManager =
            context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val time = System.currentTimeMillis()
        val usageEvents = mUsageStatsManager.queryEvents(time - 1000 * 60 * 3, time) ?: return false
        var count = 0
        while (usageEvents.hasNextEvent()) {
            count++
            if (count > 0) return true
        }
        return false
    }

    @Suppress("DEPRECATION")
    @JvmStatic
    fun findBackgrounProcess(context: Context, pkgNameToFind: String): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            val mUsageStatsManager =
                context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val time = System.currentTimeMillis()
//            var lastEventTimeRemove: Long = -1
//            var lastEventTimeAdd: Long = 0
            val usageEvents =
                mUsageStatsManager.queryEvents(time - 1000 * 60 * 2, time)
            // Sort the stats by the last time used
            if (usageEvents != null) {
                while (usageEvents.hasNextEvent()) {
                    val event = UsageEvents.Event()
                    usageEvents.getNextEvent(event)
                    val pkg = event.packageName
                    if (pkg.contains(pkgNameToFind)) {
//                        val type = event.eventType
//                        when (type) {
//                            AccessibilityEvent.WINDOWS_CHANGE_REMOVED -> lastEventTimeRemove =
//                                event.timeStamp
//                            AccessibilityEvent.WINDOWS_CHANGE_ADDED -> lastEventTimeAdd =
//                                event.timeStamp
//                        }
//                        when (type) {
//                            UsageEvents.Event.MOVE_TO_BACKGROUND -> lastEventTimeRemove =
//                                event.timeStamp
//                            UsageEvents.Event.MOVE_TO_FOREGROUND -> lastEventTimeAdd =
//                                event.timeStamp
//                        }
                        return true
                    }
                }
            }; //return lastEventTimeRemove < lastEventTimeAdd
        }
        else {
            val activityManager =
                (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
            val recentTasks =
                activityManager.getRecentTasks(MAX_RECENT_TASKS, 0)
            for (task in recentTasks) {
                val pkg = task.baseIntent.component!!.packageName
                if (pkg.contains(pkgNameToFind)) {
//                    activityManager.killBackgroundProcesses(task.baseIntent.getPackage())
                    return true
                }
            }
        }
        return false
    }
}