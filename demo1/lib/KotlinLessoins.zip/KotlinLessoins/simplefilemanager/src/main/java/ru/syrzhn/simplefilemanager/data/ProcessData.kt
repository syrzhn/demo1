package ru.syrzhn.simplefilemanager.data

class ProcessData {
    var id: String? = null
        private set
    var name: String? = null
        private set
    var description: String? = null
        private set

    fun setId(id: String?): ProcessData {
        this.id = id
        return this
    }

    fun setName(name: String?): ProcessData {
        this.name = name
        return this
    }

    fun setDescription(description: String?): ProcessData {
        this.description = description
        return this
    }

    override fun toString(): String {
        return String.format(
            "id: %s;\nname: %s;\ndescription: %s;",
            id,
            name,
            description
        )
    }
}