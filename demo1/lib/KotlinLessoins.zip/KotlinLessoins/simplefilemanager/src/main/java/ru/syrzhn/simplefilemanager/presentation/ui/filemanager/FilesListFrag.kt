package ru.syrzhn.simplefilemanager.presentation.ui.filemanager

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.*
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.files_list_frag.*
import permissions.dispatcher.NeedsPermission
import permissions.dispatcher.OnShowRationale
import permissions.dispatcher.PermissionRequest
import permissions.dispatcher.PermissionUtils
import ru.syrzhn.simplefilemanager.*
import ru.syrzhn.simplefilemanager.SDCardOperations.Companion.createFolderOnSDCard
import ru.syrzhn.simplefilemanager.SDCardOperations.Companion.getChildrenOnSDCard
import ru.syrzhn.simplefilemanager.SDCardOperations.Companion.pathOnSDCard
import ru.syrzhn.simplefilemanager.SDCardOperations.Companion.renameOnSDCard
import ru.syrzhn.simplefilemanager.data.AboutFile
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_FOLDER
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_UNKNOWN
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_UPDIR
import ru.syrzhn.simplefilemanager.domain.Domain.Companion.getSize
import ru.syrzhn.simplefilemanager.presentation.ui.*
import ru.syrzhn.simplefilemanager.presentation.ui.AlertDialogMessages.Companion.alreadyExists
import ru.syrzhn.simplefilemanager.presentation.ui.AlertDialogMessages.Companion.nameIsNull
import ru.syrzhn.simplefilemanager.presentation.ui.AlertDialogMessages.Companion.noItemsSelected
import ru.syrzhn.simplefilemanager.presentation.ui.AlertDialogMessages.Companion.noResults
import ru.syrzhn.simplefilemanager.presentation.ui.AlertDialogMessages.Companion.showOnFirstStart
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.backPressed
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.currentPath
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.rootPath
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.sdCardPath
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.upPath
import java.io.File
import java.lang.ref.WeakReference
import java.util.*

@Suppress("DEPRECATION")
class FilesListFrag : AFilesListFrag() {

    private lateinit var mView: View
    lateinit var mainActivity: MainActivity
    val listAdapter = FilesListAdapter()
    var fileTreeDepth = 0
    lateinit var result: List<File>
    private lateinit var latestPathBeforeAction: File

    private val REQUEST_LOADFILES: Int = 0

    private val PERMISSION_LOADFILES: Array<String> =
        arrayOf("android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE")


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.files_list_frag, container, false)
        return mView
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        try {
            super.onActivityResult(requestCode, resultCode, data!!)
            if (requestCode == 1000 || requestCode == 1001) {
                val uri = data.data
                activity?.grantUriPermission(
                    activity?.packageName, uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                val takeFlags = data.flags and (Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_READ_URI_PERMISSION)
                activity?.contentResolver?.takePersistableUriPermission(uri!!, takeFlags)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadFilesWithPermissionCheck()
        fun sdCardPathIsNull() {
            if (sdCardPath == null) {
                SDCard.isEnabled = false
                SDCard.backgroundTintList =
                    AppCompatResources.getColorStateList(context!!, R.color.disabled)
                SDCard.text = getString(R.string.no_sdcard)
            }
            else {
                if (pathOnSDCard(currentPath.absolutePath)) {
                    Internal.backgroundTintList =
                        AppCompatResources.getColorStateList(context!!, R.color.button)
                    SDCard.backgroundTintList =
                        AppCompatResources.getColorStateList(context!!, R.color.button_pressed)
                }
            }
        }
        sdCardPathIsNull()

        Internal.setOnClickListener {
            currentPath = rootPath
            Internal.backgroundTintList =
                AppCompatResources.getColorStateList(context!!, R.color.button_pressed)
            if (sdCardPath != null) {
                SDCard.backgroundTintList =
                    AppCompatResources.getColorStateList(context!!, R.color.button)
            }
            loadFilesWithPermissionCheck()
        }

        SDCard.setOnClickListener {
            if (sdCardPath != null) {
                Internal.backgroundTintList =
                    AppCompatResources.getColorStateList(context!!, R.color.button)
                SDCard.backgroundTintList =
                    AppCompatResources.getColorStateList(context!!, R.color.button_pressed)
                if (getUri(context!!) == null)
                    sdCardPermissions(sdCardPath)
                currentPath = sdCardPath
            }
            else {
                sdCardPathIsNull()
            }
            loadFilesWithPermissionCheck()
        }

        backPressed = object: IOnBackPressed {
            override fun onBackPressed(): Boolean {
                if (currentPath != rootPath && currentPath != sdCardPath && !listAdapter.btnSearchPressed) {
                    val location = currentPath.toString().substring(0,
                        currentPath.toString().lastIndexOf("/") + 1)
                    currentPath = File(location)

                    loadFiles()
                    return false
                }
                else if (listAdapter.btnSearchPressed && fileTreeDepth > 0) {
                    fileTreeDepth--

                    if (fileTreeDepth == 0)
                        listAdapter.setFiles(fillList(result))
                    else {
                        val location =
                            currentPath.toString().substring(0, currentPath.toString().lastIndexOf("/") + 1)
                        currentPath = File(location)

                        loadFiles()
                    }
                    return false
                }
                return true
            }
        }

        create_folder.setOnClickListener {
            createFolderBuilder()
        }

        select_all.setOnClickListener {
            selectAllOperation()
        }

        delete_selected.setOnClickListener {
            deleteSelectedBuilder()
        }

        copy_selected.setOnClickListener {
            copySelectedOperation()
        }

        move_selected.setOnClickListener {
            moveSelectedOperation()
        }

        search.setOnClickListener {
            searchButtonOperations()
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            mainActivity = context as MainActivity
        } catch (e: ClassCastException) {
            e.printStackTrace()
        }
    }

    companion object {
        private const val ARG_SECTION_NUMBER0 = "section_number"
        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        @JvmStatic
        fun getInstance(sectionNumber: Int): FilesListFrag {
            if (instance == null) {
                instance = FilesListFrag()
                .apply {
                    arguments = Bundle().apply {
                        putInt(ARG_SECTION_NUMBER0, sectionNumber)
                    }
                }
            }
            return instance as FilesListFrag
        }

        private var instance: FilesListFrag? = null
    }

    @NeedsPermission(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
    override fun loadFiles() {
        try {
            rvFiles.layoutManager = LinearLayoutManager(activity?.applicationContext)
            rvFiles.adapter = listAdapter
            listAdapter.setFiles(AsyncGetAllFiles().execute(this).get())
            listAdapter.itemClickListener = this
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        onRequestPermissionsResult(requestCode, grantResults)

        val prefs = context!!.getSharedPreferences("prefs", AppCompatActivity.MODE_PRIVATE)
        val firstStart = prefs.getBoolean("firstStart", true)

        if (firstStart)
            showOnFirstStart(context!!)
    }

    override fun onItemClick(file: AboutFile) {
        when (file.mimeType) {
            TYPE_FOLDER -> openFolder(file)
            TYPE_UPDIR -> openFolder(file)
            TYPE_UNKNOWN -> openUnknown(file)
            else -> openFile(file)
        }
    }

    override fun onItemLongClick(position: Int, view: View): Boolean {
        if (!listAdapter.btnSearchPressed && !listAdapter.btnCopyPressed && !listAdapter.btnMovePressed) {
            val wrapper = ContextThemeWrapper(this.context, R.style.NoPopupAnimation)
            val popup = PopupMenu(wrapper, view, Gravity.END)
            popup.inflate(R.menu.menu_options)

            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.open_with -> {
                        openUnknown(listAdapter.getItem(position))
                        true
                    }
                    R.id.copy -> {
                        listAdapter.popupMenuPressed = true
                        listAdapter.clearSelectedList()
                        listAdapter.addToSelectedList(listAdapter.getItem(position))
                        copySelectedOperation()
                        true
                    }
                    R.id.move -> {
                        listAdapter.popupMenuPressed = true
                        listAdapter.clearSelectedList()
                        listAdapter.addToSelectedList(listAdapter.getItem(position))
                        moveSelectedOperation()
                        true
                    }
                    R.id.rename -> {
                        renameFile(view, position)
                        true
                    }
                    R.id.delete -> {
                        listAdapter.popupMenuPressed = true
                        listAdapter.clearSelectedList()
                        listAdapter.addToSelectedList(listAdapter.getItem(position))
                        deleteSelectedBuilder()
                        true
                    }
                    else -> false
                }
            }
            try {
                val fieldMPopup = PopupMenu::class.java.getDeclaredField("mPopup")
                fieldMPopup.isAccessible = true
                val mPopup = fieldMPopup.get(popup)
                mPopup.javaClass.getDeclaredMethod("setForceShowIcon", Boolean::class.java)
                    .invoke(mPopup, true)
            } catch (e: Exception) {
                Log.e("Main", "Error showing menu icons.", e)
            } finally {
                popup.show()
            }
            return false
        }
        return false
    }

    override fun fillList(fileList: List<File>): List<AboutFile> {
        val mutableFileList = mutableListOf<AboutFile>()
        if (fileList.isEmpty()) {
            val topFolder = AboutFile(
                " . . ",
                currentPath.absolutePath,
                upPath.path,
                TYPE_UPDIR,
                false
            )
            mutableFileList += topFolder
            return mutableFileList
        }

        for (file in fileList) {
            val uri = file.path
            val uriWithoutPrefix = uri.removePrefix("/storage/emulated/0/")
            val extension = uri.substring(uri.lastIndexOf(".") + 1).toLowerCase(Locale.ROOT)
            val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            val name = if (listAdapter.btnSearchPressed) uriWithoutPrefix else file.name
            val selected = (activity as MainActivity).findFilesInSelected(file)
            val size = getSize(file)


            when {
                file.isDirectory -> mutableFileList += AboutFile(
                    name,
                    size,
                    uri,
                    TYPE_FOLDER,
                    selected
                )
                mimeType.isNullOrEmpty() -> mutableFileList += AboutFile(
                    name,
                    size,
                    uri,
                    TYPE_UNKNOWN,
                    selected
                )
                else -> mutableFileList += AboutFile(
                    name,
                    size,
                    uri,
                    mimeType.toString(),
                    selected
                )
            }
        }
        return sortList(mutableFileList)
    }

    private fun sortList(list: List<AboutFile>): List<AboutFile> {
        val folderList = mutableListOf<AboutFile>()
        val fileList = mutableListOf<AboutFile>()

        for (file in list) {
            if (file.mimeType == TYPE_FOLDER)
                folderList.add(file)
            else
                fileList.add(file)
        }
        folderList.sortBy { it.name.toLowerCase(Locale.ROOT) }
        fileList.sortBy { it.name.toLowerCase(Locale.ROOT) }

        if (currentPath != rootPath && currentPath != sdCardPath) {
            val topFolder = AboutFile(
                " . . ",
                currentPath.absolutePath,
                upPath.path,
                TYPE_UPDIR,
                false
            )
            folderList.add(0, topFolder)
        }
        return folderList + fileList
    }

    override fun onItemSelect(file: AboutFile) {
        (activity as MainActivity).addFileToSelected(file)
    }

    @SuppressLint("InflateParams")
    private fun createFolderBuilder() {
        val dialogView = LayoutInflater.from(context!!).inflate(R.layout.layout_dialog, null)
        val customTitle = LayoutInflater.from(context!!).inflate(R.layout.custom_title, null)
        customTitle.findViewById<TextView>(R.id.title_text).text = getString(R.string.create_new_folder)

        val builder = AlertDialog.Builder(context!!)
            .setView(dialogView)
            .setCustomTitle(customTitle)
            .setCancelable(false)
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                createFolder(
                    dialogView.findViewById<EditText>(R.id.name_input).text.toString()
                )
            }
            .setNegativeButton(getString(R.string.cancel), null)
        builder.show()
    }

    private fun selectAllOperation() {
        if (!listAdapter.btnSelectAllPressed) {
            listAdapter.btnSelectAllPressed = true
            listAdapter.addAllToSelectedList()
            loadFiles()
        }
        else {
            listAdapter.btnSelectAllPressed = false
            listAdapter.clearSelectedList()
            loadFiles()
        }
    }

    @SuppressLint("InflateParams")
    fun deleteSelectedBuilder() {
        val selectedList = listAdapter.getSelectedList()
        val message = if (selectedList.size == 1)
                getString(R.string.delete_item) + selectedList[0].name
            else
                getString(R.string.delete_selected_items)

        val customTitle = LayoutInflater.from(context).inflate(R.layout.custom_title, null)
        customTitle.findViewById<TextView>(R.id.title_text).text = getString(R.string.are_you_sure)
        val customText = LayoutInflater.from(context).inflate(R.layout.custom_text_alertdialog, null)
        customText.findViewById<TextView>(R.id.custom_text).text = message

        val builder = AlertDialog.Builder(context!!)
            .setCustomTitle(customTitle)
            .setView(customText)
            .setCancelable(false)
            .setPositiveButton(getString(R.string.yes)) { _, _ ->
                AsyncDeleteSelected(this).execute(this)
                listAdapter.popupMenuPressed = false
            }
            .setNegativeButton(getString(R.string.no)) { _, _ ->
                if (listAdapter.popupMenuPressed) {
                    listAdapter.popupMenuPressed = false
                    listAdapter.clearSelectedList()
                }
            }

        if (!selectedList.isNullOrEmpty())
            builder.show()
        else
            noItemsSelected(context!!)
    }

    private fun copySelectedOperation() {
        val selectedList = listAdapter.getSelectedList()

        if (! listAdapter.btnMovePressed && ! listAdapter.btnCopyPressed && !selectedList.isNullOrEmpty()) {
            listAdapter.btnCopyPressed = true
            latestPathBeforeAction = currentPath

            setButton(select_all)
            setButton(delete_selected)
            setButton(move_selected)
            search.setImageResource(R.drawable.cancel)
            copy_selected.setImageResource(R.drawable.ok)
        }
        else if (listAdapter.btnCopyPressed) {
            listAdapter.btnCopyPressed = false

            copySelectedFiles()
            listAdapter.popupMenuPressed = false

            setButton(select_all)
            setButton(delete_selected)
            setButton(move_selected)
            search.setImageResource(R.drawable.search)
            copy_selected.setImageResource(R.drawable.copy)
        }
        else
            noItemsSelected(context!!)
    }

    private fun moveSelectedOperation() {
        val selectedList = listAdapter.getSelectedList()

        if (! listAdapter.btnCopyPressed && ! listAdapter.btnMovePressed && !selectedList.isNullOrEmpty()) {
            listAdapter.btnMovePressed = true
            latestPathBeforeAction = currentPath

            setButton(select_all)
            setButton(delete_selected)
            setButton(copy_selected)
            search.setImageResource(R.drawable.cancel)
            move_selected.setImageResource(R.drawable.ok)
        }
        else if (listAdapter.btnMovePressed) {
            listAdapter.btnMovePressed = false

            moveSelectedFiles()
            listAdapter.popupMenuPressed = false

            setButton(select_all)
            setButton(delete_selected)
            setButton(copy_selected)
            search.setImageResource(R.drawable.search)
            move_selected.setImageResource(R.drawable.move)
        }
        else {
            noItemsSelected(context!!)
        }
    }

    @SuppressLint("UseCompatLoadingForColorStateLists", "InflateParams")
    fun searchButtonOperations() {
        if (listAdapter.btnCopyPressed) {
            listAdapter.btnCopyPressed = false

            if (latestPathBeforeAction != currentPath)
                listAdapter.clearSelectedList()

            setButton(select_all)
            setButton(delete_selected)
            setButton(move_selected)
            search.setImageResource(R.drawable.search)
            copy_selected.setImageResource(R.drawable.copy)
        }
        else if (listAdapter.btnMovePressed) {
            listAdapter.btnMovePressed = false

            if (latestPathBeforeAction != currentPath)
                listAdapter.clearSelectedList()

            setButton(select_all)
            setButton(delete_selected)
            setButton(copy_selected)
            search.setImageResource(R.drawable.search)
            move_selected.setImageResource(R.drawable.move)
        }
        else if (! listAdapter.btnSearchPressed) {
            val dialogView = LayoutInflater.from(activity!!.applicationContext).inflate(R.layout.layout_dialog, null)
            val customTitle = LayoutInflater.from(activity!!.applicationContext).inflate(R.layout.custom_title, null)
            customTitle.findViewById<TextView>(R.id.title_text).text = getString(R.string.search)

            val builder = AlertDialog.Builder(context!!)
                .setView(dialogView)
                .setCustomTitle(customTitle)
                .setCancelable(false)
                .setPositiveButton(getString(R.string.ok)) { _, _ ->

                    if (dialogView.findViewById<EditText>(R.id.name_input).text.toString()
                            .isNotEmpty()
                    ) {
                        latestPathBeforeAction = currentPath
                        result = search(
                            dialogView.findViewById<EditText>(R.id.name_input).text.toString())

                        if (result.isNullOrEmpty())
                            noResults(context!!)
                        else {
                            listAdapter.btnSearchPressed = true
                            rvFiles.adapter = listAdapter
                            listAdapter.setFiles(fillList(result))

                            Internal.isEnabled = false
                            Internal.backgroundTintList = activity!!.applicationContext.resources.getColorStateList(R.color.disabled)
                            SDCard.isEnabled = false
                            SDCard.backgroundTintList = activity!!.applicationContext.resources.getColorStateList(R.color.disabled)

                            setButton(create_folder)
                            setButton(select_all)
                            setButton(delete_selected)
                            setButton(copy_selected)
                            setButton(move_selected)
                            search.setImageResource(R.drawable.cancel)
                        }
                    }
                    else {
                        nameIsNull(context!!)
                    }
                }
                .setNegativeButton(getString(R.string.cancel), null)
            builder.show()
        }
        else if (listAdapter.btnSearchPressed) {
            currentPath = latestPathBeforeAction
            listAdapter.btnSearchPressed = false
            loadFiles()
            Internal.isEnabled = true

            if (currentPath.toString().contains(rootPath.toString()))
                Internal.backgroundTintList = activity!!.applicationContext.resources.getColorStateList(R.color.button_pressed)
            else
                Internal.backgroundTintList = activity!!.applicationContext.resources.getColorStateList(R.color.button)

            if (sdCardPath != null) {
                SDCard.isEnabled = true

                if (currentPath.toString().contains(sdCardPath.toString()))
                    SDCard.backgroundTintList = activity!!.applicationContext.resources.getColorStateList(R.color.button_pressed)
                else
                    SDCard.backgroundTintList = activity!!.applicationContext.resources.getColorStateList(R.color.button)
            }
            setButton(create_folder)
            setButton(select_all)
            setButton(delete_selected)
            setButton(copy_selected)
            setButton(move_selected)
            search.setImageResource(R.drawable.search)
        }
        if (listAdapter.popupMenuPressed) {
            listAdapter.popupMenuPressed = false
            listAdapter.clearSelectedList()

            if (currentPath == latestPathBeforeAction)
                listAdapter.setFiles(AsyncGetAllFiles().execute(this).get())
        }
    }

    @SuppressLint("UseCompatLoadingForColorStateLists")
    private fun setButton(button: ImageButton) {
        if (button.isEnabled) {
            button.isEnabled = false
            button.backgroundTintList = activity!!.applicationContext.resources.getColorStateList(R.color.disabled)
        }
        else {
            button.isEnabled = true
            button.backgroundTintList = activity!!.applicationContext.resources.getColorStateList(R.color.button)
        }
    }

    private fun openFile(file: AboutFile) {
        val intent = Intent(Intent.ACTION_VIEW)

        if (currentPath.toString().contains(sdCardPath.toString())) {
            val uri = getChildrenOnSDCard(currentPath, this)?.findFile(file.name)?.uri
            intent.setDataAndType(uri, file.mimeType)
        }
        else {
            intent.setDataAndType(
                FileProvider.getUriForFile(
                    activity!!.applicationContext,
                    activity!!.applicationContext.packageName + ".provider",
                    File(file.uri)
                ), file.mimeType
            )
        }
        intent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        startActivity(intent)
    }

    private fun openFolder(file: AboutFile) {
        if (file.mimeType == TYPE_FOLDER || file.mimeType == TYPE_UPDIR) {
            if (listAdapter.btnSearchPressed)
                fileTreeDepth++

            currentPath = File(file.uri)
            loadFiles()
        }
    }

    private fun openUnknown(file: AboutFile) {
        val intent = Intent(Intent.ACTION_VIEW)

        intent.setDataAndType(
            FileProvider.getUriForFile(
                context!!,
                context!!.packageName + ".provider",
                File(file.uri)
            ), "*/*"
        )
        intent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        context!!.startActivity(intent)
    }

    private fun createFolder(name: String) {
        if (currentPath.toString().contains(sdCardPath.toString())) {
            createFolderOnSDCard(currentPath, name, this)
            loadFilesWithPermissionCheck()
        }
        else {
            try {
                val folder = File(currentPath, name)
                if (!folder.exists()) {
                    folder.mkdir()
                    loadFiles()
                } else if (name.isEmpty())
                    nameIsNull(context!!)
                else
                    alreadyExists(name, context!!)
            } catch (e: Exception) {
                loadFilesWithPermissionCheck()
            }
        }
    }

    @SuppressLint("InflateParams")
    fun renameFile(view: View, position: Int) {
        val currentItem = listAdapter.getItem(position)
        val dialogView = LayoutInflater.from(view.context).inflate(R.layout.layout_dialog, null)
        dialogView.findViewById<EditText>(R.id.name_input).setText(currentItem.name)

        val customTitle = LayoutInflater.from(context).inflate(R.layout.custom_title, null)
        customTitle.findViewById<TextView>(R.id.title_text).text = getString(R.string.rename_upper)

        val builder = AlertDialog.Builder(view.context)
            .setView(dialogView)
            .setCustomTitle(customTitle)
            .setCancelable(false)
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                val file = File(currentItem.uri)
                val newName = dialogView.findViewById<EditText>(R.id.name_input).text.toString()

                if (newName.isNotEmpty()) {
                    if (currentPath.toString().contains(sdCardPath.toString())) {
                        renameOnSDCard(currentItem, newName, this)
                        loadFiles()
                    }
                    else {
                        file.renameTo(File(currentPath, newName))
                        loadFiles()
                    }
                }
                else {
                    nameIsNull(context!!)
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
        builder.show()
    }

    private fun copySelectedFiles() {
        AsyncCopySelected(this).execute(this)
    }

    private fun moveSelectedFiles() {
        AsyncMoveSelected(this).execute(this)
    }

    private fun search(input: String): List<File> {
        return AsyncSearch(input).execute(this).get()
    }

    private fun loadFilesWithPermissionCheck() {
        if (PermissionUtils.hasSelfPermissions(context, *PERMISSION_LOADFILES)) {
            loadFiles()
        } else {
            if (PermissionUtils.shouldShowRequestPermissionRationale(this, *PERMISSION_LOADFILES)) {
                showRationaleForStoragePermissions(FileManagerActivityLoadFilesPermissionRequest(this))
            } else {
                ActivityCompat.requestPermissions(activity!!, PERMISSION_LOADFILES, REQUEST_LOADFILES)
            }
        }
    }

    @SuppressLint("InflateParams")
    @OnShowRationale(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
    private fun AFilesListFrag.showRationaleForStoragePermissions(request: PermissionRequest) {
        val customTitle =
            LayoutInflater.from(activity!!.applicationContext).inflate(R.layout.custom_title, null)
        customTitle.findViewById<TextView>(R.id.title_text).text = getString(R.string.attention)
        val customText =
            LayoutInflater.from(activity!!.applicationContext)
                .inflate(R.layout.custom_text_alertdialog, null)
        customText.findViewById<TextView>(R.id.custom_text).text = getString(R.string.rationale)

        val builder = AlertDialog.Builder(context!!)
            .setView(customText)
            .setCustomTitle(customTitle)
            .setCancelable(false)
            .setPositiveButton(getString(R.string.proceed)) { _, _ -> request.proceed() }
            .setNegativeButton(getString(R.string.exit)) { _, _ -> request.cancel() }
            .create()
        builder.show()
    }

    fun onRequestPermissionsResult(requestCode: Int, grantResults: IntArray) {
        when (requestCode) {
            REQUEST_LOADFILES ->
            {
                if (PermissionUtils.verifyPermissions(*grantResults)) {
                    loadFiles()
                }
            }
        }
    }

    inner class FileManagerActivityLoadFilesPermissionRequest(target: AFilesListFrag) : PermissionRequest {
        private val weakTarget: WeakReference<AFilesListFrag> = WeakReference(target)

        override fun proceed() {
            val target = weakTarget.get() ?: return
            ActivityCompat.requestPermissions(
                target.activity!!,
                PERMISSION_LOADFILES,
                REQUEST_LOADFILES
            )
        }

        override fun cancel() {
        }
    }
}