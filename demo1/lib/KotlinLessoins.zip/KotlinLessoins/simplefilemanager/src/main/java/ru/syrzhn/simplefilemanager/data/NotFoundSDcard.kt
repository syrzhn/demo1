package ru.syrzhn.simplefilemanager.data

class NotFoundSDcard : ExceptionInInitializerError() {
    override val message: String
        get() = "Not found external sd card"
}