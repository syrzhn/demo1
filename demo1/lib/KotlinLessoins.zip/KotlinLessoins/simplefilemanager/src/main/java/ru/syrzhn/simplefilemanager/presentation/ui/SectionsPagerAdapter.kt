package ru.syrzhn.simplefilemanager.presentation.ui

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import ru.syrzhn.simplefilemanager.R
import ru.syrzhn.simplefilemanager.presentation.ui.filemanager.FilesListFrag
import ru.syrzhn.simplefilemanager.presentation.ui.secretfolder.SecretFolderFrag
import ru.syrzhn.simplefilemanager.presentation.ui.selected.SelectedListFrag

private val TAB_TITLES = arrayOf(
    R.string.tab_text_1,
    R.string.tab_text_2,
    R.string.tab_text_3
)

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
class SectionsPagerAdapter(private val context: Context, fm: FragmentManager) :
    FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    val filesListFrag = FilesListFrag.getInstance(0)
    val selectedListFrag = SelectedListFrag.getInstance(1)
    val secretFolderFrag = SecretFolderFrag.getInstance(2)

    override fun getItem(position: Int): Fragment {
        // getItem is called to instantiate the fragment for the given page.
        // Return a PlaceholderFragment (defined as a static inner class below).
        return when (position) {
            0 -> filesListFrag
            1 -> selectedListFrag
            2 -> secretFolderFrag
            else -> PlaceholderFragment.newInstance(position + 1)
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return context.resources.getString(TAB_TITLES[position])
    }

    override fun getCount(): Int {
        // Show 3 total pages.
        return 3
    }
}