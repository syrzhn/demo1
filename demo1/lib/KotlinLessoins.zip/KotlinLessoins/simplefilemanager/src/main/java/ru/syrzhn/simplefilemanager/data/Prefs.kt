package ru.syrzhn.simplefilemanager.data

class Prefs {
    companion object {
        const val PREF_NAME = "simple_file_manager_0"
        const val CURRENT_PATH = "current_path"
        const val SLECTED_PATHS = "selected_paths"
    }
}