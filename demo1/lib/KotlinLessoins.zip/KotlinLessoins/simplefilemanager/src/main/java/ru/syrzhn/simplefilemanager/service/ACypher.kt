package ru.syrzhn.simplefilemanager.service

import android.os.CountDownTimer

abstract class ACypher(private val mDelay: Long, tickTime: Long) : Runnable {
    @JvmField
    protected var mTimer: CountDownTimer?
    override fun run() {
        if (mDelay > 0 && mTimer != null) {
            mTimer!!.start()
        } else {
            finish()
        }
    }

    abstract fun finish()
    abstract fun tickTimer()
    fun cancel() {
        mTimer!!.cancel()
    }

    init {
        mTimer = object : CountDownTimer(mDelay, tickTime) {
            override fun onTick(l: Long) {
                tickTimer()
            }

            override fun onFinish() {
                finish()
            }
        }
    }
}