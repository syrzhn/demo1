package ru.syrzhn.simplefilemanager.presentation.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.storage.StorageManager
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import permissions.dispatcher.NeedsPermission
import permissions.dispatcher.OnShowRationale
import permissions.dispatcher.PermissionRequest
import ru.syrzhn.simplefilemanager.R
import ru.syrzhn.simplefilemanager.data.AboutFile
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.sdCardPath
import java.io.File

abstract class AFilesListFrag : Fragment() {

    var fragListAdapter: RecyclerView.Adapter<out RecyclerView.ViewHolder?>? = null

    @NeedsPermission(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
    abstract fun loadFiles()

    abstract fun fillList(fileList: List<File>): List<AboutFile>

    abstract fun onItemClick(file: AboutFile)

    abstract fun onItemLongClick(position: Int, view: View): Boolean

    abstract fun onItemSelect(file: AboutFile)

    fun getUri(context: Context): Uri? {
        try {
            val persistedUriPermissions = context.contentResolver.persistedUriPermissions
            if (persistedUriPermissions.size > 0) {
                val uriPermission = persistedUriPermissions[0]
                return uriPermission.uri
            }
        } catch (e: Exception) {
            sdCardPermissions(sdCardPath!!)
        }
        return null
    }

    @Suppress("DEPRECATION")
    fun sdCardPermissions(sdCardRootPath: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && Build.VERSION.SDK_INT < 29) {
            try {
                val storageManager = context!!.getSystemService(AppCompatActivity.STORAGE_SERVICE) as StorageManager
                val storageVolume = storageManager.getStorageVolume(sdCardRootPath)
                val intent = storageVolume?.createAccessIntent(null)
                startActivityForResult(intent, 1000)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        else {
            try {
                sdCardPermissionsBuilder(this)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @SuppressLint("InflateParams")
    fun sdCardPermissionsBuilder(frag: AFilesListFrag) {
        val customTitle =
            LayoutInflater.from(frag.context).inflate(R.layout.custom_title, null)
        customTitle.findViewById<TextView>(R.id.title_text).text = frag.getString(
            R.string.info
        )
        val customText =
            LayoutInflater.from(frag.context).inflate(R.layout.custom_text_alertdialog, null)
        customText.findViewById<TextView>(R.id.custom_text).text =
            frag.getString(R.string.sdcard_permission)

        val builder = AlertDialog.Builder(frag.context!!)
            .setCustomTitle(customTitle)
            .setView(customText)
            .setCancelable(false)
            .setPositiveButton(frag.getString(R.string.ok)) { _, _ ->
                frag.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 1001)
            }
        builder.show()
    }
}