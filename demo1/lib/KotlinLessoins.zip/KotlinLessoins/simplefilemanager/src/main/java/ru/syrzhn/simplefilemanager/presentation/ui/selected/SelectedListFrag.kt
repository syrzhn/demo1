package ru.syrzhn.simplefilemanager.presentation.ui.selected

import android.Manifest
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.selected_list_frag.*
import permissions.dispatcher.NeedsPermission
import ru.syrzhn.simplefilemanager.R
import ru.syrzhn.simplefilemanager.data.AboutFile
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_FOLDER
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_UNKNOWN
import ru.syrzhn.simplefilemanager.domain.Domain
import ru.syrzhn.simplefilemanager.presentation.ui.AFilesListFrag
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity.Companion.selectedFilesList
import java.io.File
import java.util.*

class SelectedListFrag : AFilesListFrag() {

    private lateinit var mView: View

    private val selectedListAdapter = SelectedListAdapter()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.selected_list_frag, container, false)
        return mView
    }

    override fun onStart() {
        super.onStart()
        selectedListAdapter.setFiles(selectedFilesList.getItemsList())
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadFiles()
    }

    companion object {
        private const val ARG_SECTION_NUMBER1 = "section_number"
        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        @JvmStatic
        fun getInstance(sectionNumber: Int): SelectedListFrag {
            if (instance == null) {
                instance = SelectedListFrag()
                    .apply {
                        arguments = Bundle().apply {
                            putInt(ARG_SECTION_NUMBER1, sectionNumber)
                        }
                    }
            }
            return instance as SelectedListFrag
        }

        private var instance: SelectedListFrag? = null
    }

    @NeedsPermission(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
    override fun loadFiles() {
        try {
            rvSelected.layoutManager = LinearLayoutManager(activity?.applicationContext)
            rvSelected.adapter = selectedListAdapter
            selectedListAdapter.setFiles(selectedFilesList.getItemsList())
            selectedListAdapter.itemClickListener = this
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onItemClick(file: AboutFile) {
        Toast.makeText(context, "!!!!!!", Toast.LENGTH_SHORT).show()
    }

    override fun onItemLongClick(position: Int, view: View): Boolean {
        Toast.makeText(context, "?????", Toast.LENGTH_LONG).show()
        return false
    }

    override fun fillList(fileList: List<File>): List<AboutFile> {
        val mutableFileList = mutableListOf<AboutFile>()
        if (fileList.isEmpty()) {
            val topFolder = AboutFile(
                " . . ",
                "",
                MainActivity.upPath.path,
                TYPE_FOLDER,
                false
            )
            mutableFileList += topFolder
            return mutableFileList
        }

        for (file in fileList) {
            val uri = file.path
            val extension = uri.substring(uri.lastIndexOf(".") + 1).toLowerCase(Locale.ROOT)
            val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            val name = file.name
            val selected = (activity as MainActivity).findFilesInSelected(file)


            when {
                file.isDirectory -> mutableFileList += AboutFile(
                    name,
                    "",
                    uri,
                    TYPE_FOLDER,
                    selected
                )
                mimeType.isNullOrEmpty() -> mutableFileList += AboutFile(
                    name,
                    Domain.getSize(file),
                    uri,
                    TYPE_UNKNOWN,
                    selected
                )
                else -> mutableFileList += AboutFile(
                    name,
                    Domain.getSize(file),
                    uri,
                    mimeType.toString(),
                    selected
                )
            }
        }
        return sortList(mutableFileList)
    }

    private fun sortList(list: List<AboutFile>): List<AboutFile> {
        val folderList = mutableListOf<AboutFile>()
        val fileList = mutableListOf<AboutFile>()

        for (file in list) {
            if (file.mimeType == TYPE_FOLDER)
                folderList.add(file)
            else
                fileList.add(file)
        }
        folderList.sortBy { it.name.toLowerCase(Locale.ROOT) }
        fileList.sortBy { it.name.toLowerCase(Locale.ROOT) }

        if(MainActivity.currentPath != MainActivity.rootPath && MainActivity.currentPath != MainActivity.sdCardPath) {
            val topFolder = AboutFile(
                " . . ",
                "",
                MainActivity.upPath.path,
                TYPE_FOLDER,
                false
            )
            folderList.add(0, topFolder)
        }
        return folderList + fileList
    }

    override fun onItemSelect(file: AboutFile) {
        (activity as MainActivity).addFileToSelected(file)
    }
}