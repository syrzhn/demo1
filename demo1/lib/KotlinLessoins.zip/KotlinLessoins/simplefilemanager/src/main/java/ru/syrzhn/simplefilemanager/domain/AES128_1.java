package ru.syrzhn.simplefilemanager.domain;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AES128_1 {
    private static SecretKeySpec secretKey;

    public static AES128_1 getInstance(String secret0) {
        AES128_1 localInstance = instance;
        if (localInstance == null) {
            synchronized (AES128_1.class) {
                localInstance = instance;
                if (localInstance == null) {
                    instance = localInstance = new AES128_1(secret0);
                }
            }
        } return localInstance;
    }
    private static volatile AES128_1 instance;

    private AES128_1(String secret0) {
        MessageDigest sha = null;
        try {
            byte[] key = secret0.getBytes("UTF-8");
            sha = MessageDigest.getInstance("SHA-1");
            key = sha.digest(key);
            key = Arrays.copyOf(key, 16); // AES 128-bits cipher
            secretKey = new SecretKeySpec(key, "AES");
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public void encryptFile(File fileIn, File fileOut) {
        FileInputStream in = null;
        FileOutputStream out = null;
        try {
            in = new FileInputStream(fileIn);
            int size = in.available();
            byte[] bytIn = new byte[size];
            in.read(bytIn);

            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] bytOut = cipher.doFinal(bytIn);

            out = new FileOutputStream(fileOut);
            out.write(bytOut);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException
                | IllegalBlockSizeException | BadPaddingException | IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null)
                    in.close();
                if (out != null)
                    out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void decryptFile(File fileIn, File fileOut) {
        FileInputStream in = null;
        FileOutputStream out = null;
        try {
            in = new FileInputStream(fileIn);
            int size = in.available();
            byte[] bytIn = new byte[size];
            in.read(bytIn);

            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] bytOut = cipher.doFinal(bytIn);

            out = new FileOutputStream(fileOut);
            out.write(bytOut);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException	| InvalidKeyException
                | IllegalBlockSizeException | BadPaddingException | IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null)
                    in.close();
                if (out != null)
                    out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
