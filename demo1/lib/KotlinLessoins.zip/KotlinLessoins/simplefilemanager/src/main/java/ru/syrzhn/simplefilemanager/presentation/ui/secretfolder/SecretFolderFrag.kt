package ru.syrzhn.simplefilemanager.presentation.ui.secretfolder

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.secret_folder_frag.*
import ru.syrzhn.simplefilemanager.R
import ru.syrzhn.simplefilemanager.data.AboutFile
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_FOLDER
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_UNKNOWN
import ru.syrzhn.simplefilemanager.data.Constants.Companion.TYPE_UPDIR
import ru.syrzhn.simplefilemanager.domain.Domain
import ru.syrzhn.simplefilemanager.presentation.ui.AFilesListFrag
import ru.syrzhn.simplefilemanager.presentation.ui.MainActivity
import java.io.File
import java.util.*

class SecretFolderFrag : AFilesListFrag() {

    private lateinit var mView: View
    private lateinit var upDir: File
    private lateinit var mainActivity: MainActivity
    private lateinit var secretPath: File

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.secret_folder_frag, container, false)
        return mView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        secretPath = context!!.filesDir
        upDir = context!!.filesDir
        loadFiles()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            mainActivity = context as MainActivity
        } catch (e: ClassCastException) {
            e.printStackTrace()
        }
    }

    private val listAdapter = SecretFolderAdapter()

    override fun loadFiles() {
        upDir = secretPath
        try {
            val listFiles = secretPath.listFiles()?.asList()
            val list = listFiles?.let { fillList(it) }
            rvSecret.layoutManager = LinearLayoutManager(activity?.applicationContext)
            rvSecret.adapter = listAdapter
            if (list != null) {
                listAdapter.setFiles(list)
            }
            listAdapter.itemClickListener = this
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun fillList(fileList: List<File>): List<AboutFile> {
        val mutableFileList = mutableListOf<AboutFile>()
        if (fileList.isEmpty()) {
            val topFolder = AboutFile(
                " . . ",
                upDir.absolutePath,
                upDir.path,
                TYPE_UPDIR,
                false
            )
            mutableFileList += topFolder
            return mutableFileList
        }
        for (file in fileList) {
            val uri = file.path
            val extension = uri.substring(uri.lastIndexOf(".") + 1).toLowerCase(Locale.ROOT)
            val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            val name = file.name
            val selected = (activity as MainActivity).findFilesInSelected(file)
            val size = Domain.getSize(file)

            when {
                file.isDirectory -> mutableFileList += AboutFile(
                    name,
                    size,
                    uri,
                    TYPE_FOLDER,
                    selected
                )
                mimeType.isNullOrEmpty() -> mutableFileList += AboutFile(
                    name,
                    size,
                    uri,
                    TYPE_UNKNOWN,
                    selected
                )
                else -> mutableFileList += AboutFile(
                    name,
                    size,
                    uri,
                    mimeType.toString(),
                    selected
                )
            }
        }
        return sortList(mutableFileList)
    }

    private fun sortList(list: List<AboutFile>): List<AboutFile> {
        val folderList = mutableListOf<AboutFile>()
        val fileList = mutableListOf<AboutFile>()

        for (file in list) {
            if (file.mimeType == TYPE_FOLDER)
                folderList.add(file)
            else
                fileList.add(file)
        }
        folderList.sortBy { it.name.toLowerCase(Locale.ROOT) }
        fileList.sortBy { it.name.toLowerCase(Locale.ROOT) }

        val topFolder = AboutFile(
            " . . ",
            upDir.absolutePath,
            upDir.path,
            TYPE_UPDIR,
            false
        )
        folderList.add(0, topFolder)
        return folderList + fileList
    }

    companion object {
        private const val ARG_SECTION_NUMBER2 = "secret_folder"
        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        @JvmStatic
        fun getInstance(sectionNumber: Int): SecretFolderFrag {
            if (instance == null) {
                instance = SecretFolderFrag()
                    .apply {
                        arguments = Bundle().apply {
                            putInt(ARG_SECTION_NUMBER2, sectionNumber)
                        }
                    }
            }
            return instance as SecretFolderFrag
        }

        private var instance: SecretFolderFrag? = null
    }

    override fun onItemClick(file: AboutFile) {
        secretPath = File(file.uri)
        when (file.mimeType) {
            TYPE_FOLDER -> loadFiles()
            TYPE_UPDIR -> {
                secretPath = secretPath.parentFile
                loadFiles()
            }
            TYPE_UNKNOWN -> Toast.makeText(context, "???", Toast.LENGTH_SHORT).show()
            else -> Toast.makeText(context, "!!!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onItemLongClick(position: Int, view: View): Boolean {
        Toast.makeText(context, "?????", Toast.LENGTH_LONG).show()
        return false
    }

    override fun onItemSelect(file: AboutFile) {
        Toast.makeText(context, "!!!!!!", Toast.LENGTH_SHORT).show()
    }
}