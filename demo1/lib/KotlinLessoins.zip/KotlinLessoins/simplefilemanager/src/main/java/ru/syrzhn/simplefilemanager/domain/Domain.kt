package ru.syrzhn.simplefilemanager.domain

import java.io.File
import java.util.*

class Domain {
    companion object {

        @Suppress("LocalVariableName")
        fun getSize(file: File): String {
            val GB: Long = 1024 * 1024 * 1024
            val MB: Long = 1024 * 1024
            val kB: Long = 1024
            val size_in_bytes = getFileSize(file).toDouble()//file.length().toDouble()

            return when {
                size_in_bytes > GB -> String.format("%.1f", size_in_bytes / GB) + "\u00A0GB"
                size_in_bytes > MB -> String.format("%.1f", size_in_bytes / MB) + "\u00A0MB"
                size_in_bytes > kB -> String.format("%.1f", size_in_bytes / kB) + "\u00A0kB"
                else -> String.format("%.1f", size_in_bytes) + "\u00A0B"
            }
        }

        fun getFileSize(file: File?): Long {
            if (file == null || !file.exists())
                return 0
            if (!file.isDirectory)
                return file.length()
            val dirs: MutableList<File> = LinkedList()
            dirs.add(file)
            var result: Long = 0
            while (dirs.isNotEmpty()) {
                val dir = dirs.removeAt(0)
                if (!dir.exists()) continue
                val listFiles = dir.listFiles()
                if (listFiles == null || listFiles.isEmpty()) continue
                for (child in listFiles) {
                    result += child.length()
                    if (child.isDirectory)
                        dirs.add(child)
                }
            }
            return result
        }
    }
}